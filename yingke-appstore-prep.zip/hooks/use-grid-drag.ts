'use client';

import { useRef, useState, useCallback } from 'react';

export function useGridDrag<T extends { id: string }>(
  items: T[],
  onReorder: (newItems: T[]) => void,
) {
  const [draggingId, setDraggingId] = useState<string | null>(null);
  const [overIdx, setOverIdx] = useState<number | null>(null);
  const longPressTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const isDragging = useRef(false);

  const startLongPress = useCallback((id: string) => {
    longPressTimer.current = setTimeout(() => {
      isDragging.current = true;
      setDraggingId(id);
      // Haptic feedback
      if (typeof navigator !== 'undefined' && 'vibrate' in navigator) {
        navigator.vibrate(40);
      }
    }, 400);
  }, []);

  const cancelLongPress = useCallback(() => {
    if (longPressTimer.current) {
      clearTimeout(longPressTimer.current);
      longPressTimer.current = null;
    }
  }, []);

  const handlePointerDown = useCallback((id: string) => {
    isDragging.current = false;
    startLongPress(id);
  }, [startLongPress]);

  const handlePointerUp = useCallback(() => {
    cancelLongPress();
    if (isDragging.current && draggingId !== null && overIdx !== null) {
      const fromIdx = items.findIndex((i) => i.id === draggingId);
      if (fromIdx !== -1 && fromIdx !== overIdx) {
        const next = [...items];
        const [moved] = next.splice(fromIdx, 1);
        next.splice(overIdx, 0, moved);
        onReorder(next);
      }
    }
    isDragging.current = false;
    setDraggingId(null);
    setOverIdx(null);
  }, [cancelLongPress, draggingId, overIdx, items, onReorder]);

  const handlePointerEnter = useCallback((idx: number) => {
    if (isDragging.current) {
      setOverIdx(idx);
    }
  }, []);

  const handlePointerMove = useCallback(() => {
    // no-op: overIdx is updated by pointerEnter on cells
  }, []);

  return {
    draggingId,
    overIdx,
    isDragging: isDragging.current,
    handlers: { handlePointerDown, handlePointerUp, handlePointerEnter, handlePointerMove },
  };
}
