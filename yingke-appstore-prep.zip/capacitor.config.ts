import type { CapacitorConfig } from '@capacitor/cli';

const serverUrl = process.env.CAPACITOR_SERVER_URL;

const config: CapacitorConfig = {
  appId: process.env.NEXT_PUBLIC_IOS_BUNDLE_ID ?? 'com.yingke.app',
  appName: '映刻 YingKe',
  webDir: 'dist-capacitor',
  backgroundColor: '#f9f9f6',
  loggingBehavior: 'debug',
  server: serverUrl
    ? {
        url: serverUrl,
        cleartext: serverUrl.startsWith('http://'),
        androidScheme: serverUrl.startsWith('https://') ? 'https' : 'http',
      }
    : {
        iosScheme: 'capacitor',
        androidScheme: 'https',
      },
  ios: {
    contentInset: 'automatic',
    scrollEnabled: true,
  },
};

export default config;
