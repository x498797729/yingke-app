import type { CompletedWork, SceneType } from '@/lib/store';

export interface ApiProjectRecord {
  id: number;
  title: string;
  sceneId: string;
  sceneName: string;
  status: string;
  thumbnailUrl: string | null;
  generatedVideoUrl: string | null;
  durationSeconds: number | null;
  createdAt: string;
  updatedAt: string;
}

export function formatDurationFromSeconds(seconds: number | null) {
  if (!seconds || !Number.isFinite(seconds)) return '0:00';

  const minutes = Math.floor(seconds / 60);
  const remainingSeconds = Math.floor(seconds % 60);
  return `${minutes}:${String(remainingSeconds).padStart(2, '0')}`;
}

export function mapProjectToCompletedWork(
  project: ApiProjectRecord
): CompletedWork | null {
  if (!project.generatedVideoUrl) {
    return null;
  }

  return {
    id: String(project.id),
    title: project.title,
    sceneId: project.sceneId as SceneType,
    sceneName: project.sceneName,
    thumbnailUrl: project.thumbnailUrl ?? '',
    videoUrl: project.generatedVideoUrl,
    duration: formatDurationFromSeconds(project.durationSeconds),
    createdAt: new Date(project.createdAt).getTime(),
  };
}
