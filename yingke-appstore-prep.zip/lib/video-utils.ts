// Extract first frame of a video as a data URL (thumbnail)
export function extractThumbnail(videoUrl: string): Promise<string> {
  return new Promise((resolve, reject) => {
    const video = document.createElement('video');
    video.src = videoUrl;
    video.muted = true;
    video.playsInline = true;
    video.currentTime = 0.5;

    const onSeeked = () => {
      const canvas = document.createElement('canvas');
      canvas.width = 300;
      canvas.height = 400; // 3:4
      const ctx = canvas.getContext('2d')!;
      const scale = Math.max(canvas.width / video.videoWidth, canvas.height / video.videoHeight);
      const w = video.videoWidth * scale;
      const h = video.videoHeight * scale;
      ctx.drawImage(video, (canvas.width - w) / 2, (canvas.height - h) / 2, w, h);
      resolve(canvas.toDataURL('image/jpeg', 0.8));
      video.remove();
    };

    video.addEventListener('seeked', onSeeked, { once: true });
    video.addEventListener('error', reject, { once: true });
    video.load();
  });
}

// Get video duration as formatted string
export function getVideoDuration(videoUrl: string): Promise<string> {
  return new Promise((resolve) => {
    const video = document.createElement('video');
    video.src = videoUrl;
    video.muted = true;
    video.addEventListener('loadedmetadata', () => {
      const t = video.duration;
      const m = Math.floor(t / 60);
      const s = Math.floor(t % 60);
      resolve(`${m}:${String(s).padStart(2, '0')}`);
      video.remove();
    }, { once: true });
    video.addEventListener('error', () => { resolve('0:00'); video.remove(); }, { once: true });
    video.load();
  });
}
