import 'server-only';

import { type ResultSetHeader, type RowDataPacket } from 'mysql2/promise';

import { getDbPool } from '@/lib/db';

export interface ProjectRecord {
  id: number;
  title: string;
  sceneId: string;
  sceneName: string;
  status: string;
  thumbnailUrl: string | null;
  generatedVideoUrl: string | null;
  durationSeconds: number | null;
  createdAt: string;
  updatedAt: string;
}

export interface CreateProjectInput {
  title: string;
  sceneId: string;
  sceneName: string;
  status?: string;
  thumbnailUrl?: string | null;
  generatedVideoUrl?: string | null;
  durationSeconds?: number | null;
}

export interface UpdateProjectInput {
  title?: string;
  sceneId?: string;
  sceneName?: string;
  status?: string;
  thumbnailUrl?: string | null;
  generatedVideoUrl?: string | null;
  durationSeconds?: number | null;
}

type ProjectRow = RowDataPacket & {
  id: number;
  title: string;
  scene_id: string;
  scene_name: string;
  status: string;
  thumbnail_url: string | null;
  generated_video_url: string | null;
  duration_seconds: number | null;
  created_at: Date;
  updated_at: Date;
};

function mapProjectRow(row: ProjectRow): ProjectRecord {
  return {
    id: row.id,
    title: row.title,
    sceneId: row.scene_id,
    sceneName: row.scene_name,
    status: row.status,
    thumbnailUrl: row.thumbnail_url,
    generatedVideoUrl: row.generated_video_url,
    durationSeconds: row.duration_seconds,
    createdAt: row.created_at.toISOString(),
    updatedAt: row.updated_at.toISOString(),
  };
}

export async function listProjects(limit = 20) {
  const pool = getDbPool();
  const safeLimit = Math.min(Math.max(limit, 1), 100);

  const [rows] = await pool.query<ProjectRow[]>(
    `SELECT
      id,
      title,
      scene_id,
      scene_name,
      status,
      thumbnail_url,
      generated_video_url,
      duration_seconds,
      created_at,
      updated_at
    FROM projects
    ORDER BY created_at DESC
    LIMIT ?`,
    [safeLimit]
  );

  return rows.map(mapProjectRow);
}

export async function createProject(input: CreateProjectInput) {
  const pool = getDbPool();
  const [result] = await pool.execute<ResultSetHeader>(
    `INSERT INTO projects (
      title,
      scene_id,
      scene_name,
      status,
      thumbnail_url,
      generated_video_url,
      duration_seconds
    ) VALUES (?, ?, ?, ?, ?, ?, ?)`,
    [
      input.title,
      input.sceneId,
      input.sceneName,
      input.status ?? 'draft',
      input.thumbnailUrl ?? null,
      input.generatedVideoUrl ?? null,
      input.durationSeconds ?? null,
    ]
  );

  const [rows] = await pool.query<ProjectRow[]>(
    `SELECT
      id,
      title,
      scene_id,
      scene_name,
      status,
      thumbnail_url,
      generated_video_url,
      duration_seconds,
      created_at,
      updated_at
    FROM projects
    WHERE id = ?
    LIMIT 1`,
    [result.insertId]
  );

  return mapProjectRow(rows[0]);
}

export async function updateProject(id: number, input: UpdateProjectInput) {
  const pool = getDbPool();
  const updates: string[] = [];
  const values: Array<string | number | null> = [];

  if (input.title !== undefined) {
    updates.push('title = ?');
    values.push(input.title);
  }

  if (input.sceneId !== undefined) {
    updates.push('scene_id = ?');
    values.push(input.sceneId);
  }

  if (input.sceneName !== undefined) {
    updates.push('scene_name = ?');
    values.push(input.sceneName);
  }

  if (input.status !== undefined) {
    updates.push('status = ?');
    values.push(input.status);
  }

  if (input.thumbnailUrl !== undefined) {
    updates.push('thumbnail_url = ?');
    values.push(input.thumbnailUrl);
  }

  if (input.generatedVideoUrl !== undefined) {
    updates.push('generated_video_url = ?');
    values.push(input.generatedVideoUrl);
  }

  if (input.durationSeconds !== undefined) {
    updates.push('duration_seconds = ?');
    values.push(input.durationSeconds);
  }

  if (updates.length === 0) {
    throw new Error('No fields provided for update');
  }

  values.push(id);

  await pool.execute(
    `UPDATE projects
    SET ${updates.join(', ')}
    WHERE id = ?`,
    values
  );

  const [rows] = await pool.query<ProjectRow[]>(
    `SELECT
      id,
      title,
      scene_id,
      scene_name,
      status,
      thumbnail_url,
      generated_video_url,
      duration_seconds,
      created_at,
      updated_at
    FROM projects
    WHERE id = ?
    LIMIT 1`,
    [id]
  );

  if (rows.length === 0) {
    throw new Error(`Project ${id} not found`);
  }

  return mapProjectRow(rows[0]);
}

export async function deleteProject(id: number) {
  const pool = getDbPool();
  const [result] = await pool.execute<ResultSetHeader>(
    'DELETE FROM projects WHERE id = ?',
    [id]
  );

  return result.affectedRows > 0;
}
