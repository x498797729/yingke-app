import 'server-only';

import mysql, { type Pool, type RowDataPacket } from 'mysql2/promise';

declare global {
  var __yingkeDbPool: Pool | undefined;
}

function getRequiredEnv(name: string) {
  const value = process.env[name];

  if (!value) {
    throw new Error(`Missing required environment variable: ${name}`);
  }

  return value;
}

export function getDbPool() {
  if (!global.__yingkeDbPool) {
    global.__yingkeDbPool = mysql.createPool({
      host: getRequiredEnv('DATABASE_HOST'),
      port: Number(process.env.DATABASE_PORT ?? 3306),
      database: getRequiredEnv('DATABASE_NAME'),
      user: getRequiredEnv('DATABASE_USER'),
      password: getRequiredEnv('DATABASE_PASSWORD'),
      waitForConnections: true,
      connectionLimit: 10,
      queueLimit: 0,
    });
  }

  return global.__yingkeDbPool;
}

export async function pingDatabase() {
  const pool = getDbPool();
  const [rows] = await pool.query<(RowDataPacket & { now: Date; database_name: string })[]>(
    'SELECT NOW() AS now, DATABASE() AS database_name'
  );

  return rows[0];
}
