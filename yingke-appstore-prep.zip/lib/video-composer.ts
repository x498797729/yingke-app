import { PhotoFile, SceneType, SCENES } from './store';

export interface ComposeOptions {
  photos: PhotoFile[];
  scene: SceneType;
  onProgress?: (progress: number, stage: string) => void;
}

const VIDEO_WIDTH = 720;
const VIDEO_HEIGHT = 960; // 3:4
const FRAME_DURATION = 2800;    // ms per photo
const TRANSITION_DURATION = 500; // crossfade ms
const FPS = 30;

function drawImageCover(ctx: CanvasRenderingContext2D, img: HTMLImageElement, w: number, h: number) {
  const scale = Math.max(w / img.width, h / img.height);
  const sw = img.width * scale;
  const sh = img.height * scale;
  ctx.drawImage(img, (w - sw) / 2, (h - sh) / 2, sw, sh);
}

function drawTextOverlay(
  ctx: CanvasRenderingContext2D,
  scene: (typeof SCENES)[number],
  photoIndex: number,
  totalPhotos: number,
  elapsed: number,
) {
  const totalDuration = totalPhotos * FRAME_DURATION;
  const isFirst = photoIndex === 0 && elapsed < FRAME_DURATION * 0.6;
  const isLast = photoIndex === totalPhotos - 1 && elapsed > totalDuration - FRAME_DURATION * 0.6;

  if (isFirst) {
    // Scene name overlay on first photo
    const alpha = Math.min(1, elapsed / 600) * Math.min(1, (FRAME_DURATION * 0.6 - elapsed % FRAME_DURATION) / 300);
    ctx.save();
    ctx.globalAlpha = Math.max(0, alpha);
    // Bottom gradient
    const grad = ctx.createLinearGradient(0, VIDEO_HEIGHT * 0.55, 0, VIDEO_HEIGHT);
    grad.addColorStop(0, 'rgba(0,0,0,0)');
    grad.addColorStop(1, 'rgba(0,0,0,0.65)');
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, VIDEO_WIDTH, VIDEO_HEIGHT);
    // Emoji + name
    ctx.font = `bold 52px "Noto Sans SC", sans-serif`;
    ctx.fillStyle = 'white';
    ctx.textAlign = 'left';
    ctx.fillText(scene.emoji, 44, VIDEO_HEIGHT - 120);
    ctx.font = `bold 38px "Noto Sans SC", sans-serif`;
    ctx.fillText(scene.name, 44, VIDEO_HEIGHT - 68);
    ctx.font = `22px "Noto Sans SC", sans-serif`;
    ctx.fillStyle = 'rgba(255,255,255,0.7)';
    const now = new Date();
    ctx.fillText(`${now.getFullYear()}年${now.getMonth() + 1}月${now.getDate()}日`, 44, VIDEO_HEIGHT - 36);
    ctx.restore();
  }

  if (isLast) {
    // End card overlay
    const fadeIn = Math.max(0, (elapsed - (totalDuration - FRAME_DURATION * 0.6)) / 400);
    ctx.save();
    ctx.globalAlpha = Math.min(0.85, fadeIn);
    ctx.fillStyle = 'rgba(0,0,0,0.7)';
    ctx.fillRect(0, 0, VIDEO_WIDTH, VIDEO_HEIGHT);
    ctx.globalAlpha = Math.min(1, fadeIn);
    // Logo text
    ctx.font = `bold 48px "Noto Sans SC", sans-serif`;
    ctx.fillStyle = '#e8713c';
    ctx.textAlign = 'center';
    ctx.fillText('映刻 YingKe', VIDEO_WIDTH / 2, VIDEO_HEIGHT / 2 - 20);
    ctx.font = `22px "Noto Sans SC", sans-serif`;
    ctx.fillStyle = 'rgba(255,255,255,0.6)';
    ctx.fillText('用影像记录美好生活', VIDEO_WIDTH / 2, VIDEO_HEIGHT / 2 + 28);
    ctx.restore();
  }

  // Subtle photo counter (top right, all frames)
  ctx.save();
  ctx.globalAlpha = 0.55;
  ctx.font = `500 20px "Plus Jakarta Sans", sans-serif`;
  ctx.fillStyle = 'white';
  ctx.textAlign = 'right';
  ctx.shadowColor = 'rgba(0,0,0,0.4)';
  ctx.shadowBlur = 6;
  ctx.fillText(`${photoIndex + 1} / ${totalPhotos}`, VIDEO_WIDTH - 28, 52);
  ctx.restore();
}

export async function composeVideoCanvas(options: ComposeOptions): Promise<string> {
  const { photos, scene, onProgress } = options;
  const sceneConfig = SCENES.find((s) => s.id === scene)!;

  onProgress?.(0.05, '准备画布...');

  const canvas = document.createElement('canvas');
  canvas.width = VIDEO_WIDTH;
  canvas.height = VIDEO_HEIGHT;
  const ctx = canvas.getContext('2d', { alpha: false })!;

  // Load images
  onProgress?.(0.1, '加载照片...');
  const images = await Promise.all(
    photos.map(
      (p) =>
        new Promise<HTMLImageElement>((resolve, reject) => {
          const img = new Image();
          img.onload = () => resolve(img);
          img.onerror = reject;
          img.src = p.previewUrl;
        })
    )
  );

  onProgress?.(0.22, 'AI 正在智能编排...');
  await new Promise((r) => setTimeout(r, 700));

  onProgress?.(0.32, '开始渲染...');

  // MediaRecorder setup
  const stream = canvas.captureStream(FPS);
  const mimeType = ['video/webm;codecs=vp9', 'video/webm;codecs=vp8', 'video/webm']
    .find((t) => MediaRecorder.isTypeSupported(t)) ?? 'video/webm';

  const chunks: BlobPart[] = [];
  const recorder = new MediaRecorder(stream, { mimeType, videoBitsPerSecond: 5_000_000 });
  recorder.ondataavailable = (e) => { if (e.data.size > 0) chunks.push(e.data); };
  const recordingDone = new Promise<void>((res) => { recorder.onstop = () => res(); });
  recorder.start(200);

  const totalDuration = photos.length * FRAME_DURATION;
  const startTime = performance.now();

  await new Promise<void>((resolve) => {
    function frame() {
      const elapsed = performance.now() - startTime;

      if (elapsed >= totalDuration) {
        // Final frame
        ctx.clearRect(0, 0, VIDEO_WIDTH, VIDEO_HEIGHT);
        drawImageCover(ctx, images[images.length - 1], VIDEO_WIDTH, VIDEO_HEIGHT);
        drawTextOverlay(ctx, sceneConfig, photos.length - 1, photos.length, totalDuration + 100);
        recorder.stop();
        resolve();
        return;
      }

      const photoIndex = Math.min(Math.floor(elapsed / FRAME_DURATION), images.length - 1);
      const photoElapsed = elapsed % FRAME_DURATION;
      const progress = elapsed / totalDuration;

      onProgress?.(0.32 + progress * 0.58, `渲染第 ${photoIndex + 1}/${photos.length} 张...`);

      ctx.clearRect(0, 0, VIDEO_WIDTH, VIDEO_HEIGHT);

      const inTransition = photoElapsed > FRAME_DURATION - TRANSITION_DURATION && photoIndex < images.length - 1;

      if (inTransition) {
        // Crossfade
        const t = (photoElapsed - (FRAME_DURATION - TRANSITION_DURATION)) / TRANSITION_DURATION;
        const eased = t < 0.5 ? 2 * t * t : -1 + (4 - 2 * t) * t; // ease-in-out quad

        drawImageCover(ctx, images[photoIndex], VIDEO_WIDTH, VIDEO_HEIGHT);
        ctx.globalAlpha = eased;
        drawImageCover(ctx, images[photoIndex + 1], VIDEO_WIDTH, VIDEO_HEIGHT);
        ctx.globalAlpha = 1;
      } else {
        // Ken Burns: alternate pan direction per photo
        const zoomProgress = photoElapsed / FRAME_DURATION;
        const zoom = 1 + zoomProgress * 0.045;
        const panX = (photoIndex % 2 === 0 ? 1 : -1) * zoomProgress * 12;
        const panY = -zoomProgress * 8;

        ctx.save();
        ctx.translate(VIDEO_WIDTH / 2 + panX, VIDEO_HEIGHT / 2 + panY);
        ctx.scale(zoom, zoom);
        ctx.translate(-VIDEO_WIDTH / 2, -VIDEO_HEIGHT / 2);
        drawImageCover(ctx, images[photoIndex], VIDEO_WIDTH, VIDEO_HEIGHT);
        ctx.restore();
      }

      // Text overlays
      drawTextOverlay(ctx, sceneConfig, photoIndex, photos.length, elapsed);

      requestAnimationFrame(frame);
    }

    requestAnimationFrame(frame);
  });

  await recordingDone;
  onProgress?.(0.96, '输出视频...');

  const blob = new Blob(chunks, { type: mimeType });
  const url = URL.createObjectURL(blob);
  onProgress?.(1, '完成！');
  return url;
}
