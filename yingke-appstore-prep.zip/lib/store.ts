export type SceneType = 'travel' | 'food' | 'daily' | 'baby';

export interface PhotoFile {
  id: string;
  file: File;
  previewUrl: string;
  order: number;
}

export interface ProjectState {
  photos: PhotoFile[];
  scene: SceneType | null;
  generatedVideoUrl: string | null;
  projectId: string | null;
}

// ─── In-memory session state (photos are File objects, can't serialize) ───────
const state: ProjectState = {
  photos: [],
  scene: null,
  generatedVideoUrl: null,
  projectId: null,
};

// Restore non-File fields from sessionStorage on load
if (typeof window !== 'undefined') {
  try {
    const saved = sessionStorage.getItem('yingke_session');
    if (saved) {
      const parsed = JSON.parse(saved);
      state.scene = parsed.scene ?? null;
      state.generatedVideoUrl = parsed.generatedVideoUrl ?? null;
      state.projectId = parsed.projectId ?? null;
    }
  } catch {}
}

function persistSession() {
  if (typeof window === 'undefined') return;
  try {
    sessionStorage.setItem('yingke_session', JSON.stringify({
      scene: state.scene,
      generatedVideoUrl: state.generatedVideoUrl,
      projectId: state.projectId,
    }));
  } catch {}
}

export const store = {
  get: () => ({ ...state }),
  setPhotos: (photos: PhotoFile[]) => { state.photos = photos; },
  setScene: (scene: SceneType) => { state.scene = scene; persistSession(); },
  setGeneratedVideoUrl: (url: string) => { state.generatedVideoUrl = url; persistSession(); },
  setProjectId: (id: string) => { state.projectId = id; persistSession(); },
  reset: () => {
    state.photos = [];
    state.scene = null;
    state.generatedVideoUrl = null;
    state.projectId = null;
    if (typeof window !== 'undefined') sessionStorage.removeItem('yingke_session');
  },
};

// ─── Completed works (localStorage) ──────────────────────────────────────────
export interface CompletedWork {
  id: string;
  title: string;
  sceneId: SceneType;
  sceneName: string;
  thumbnailUrl: string;   // data URL of first frame
  videoUrl: string;       // blob URL (only valid in same session)
  duration: string;
  createdAt: number;
}

const WORKS_KEY = 'yingke_works';

export const worksStore = {
  getAll: (): CompletedWork[] => {
    if (typeof window === 'undefined') return [];
    try {
      return JSON.parse(localStorage.getItem(WORKS_KEY) ?? '[]');
    } catch { return []; }
  },

  add: (work: CompletedWork) => {
    if (typeof window === 'undefined') return;
    try {
      const all = worksStore.getAll();
      // Keep max 20
      const updated = [work, ...all].slice(0, 20);
      localStorage.setItem(WORKS_KEY, JSON.stringify(updated));
    } catch {}
  },

  remove: (id: string) => {
    if (typeof window === 'undefined') return;
    try {
      const filtered = worksStore.getAll().filter((w) => w.id !== id);
      localStorage.setItem(WORKS_KEY, JSON.stringify(filtered));
    } catch {}
  },

  clear: () => {
    if (typeof window === 'undefined') return;
    localStorage.removeItem(WORKS_KEY);
  },
};

// ─── Scenes config ────────────────────────────────────────────────────────────
export const SCENES = [
  {
    id: 'travel' as SceneType,
    emoji: '🌅',
    name: '旅行日记',
    description: '温暖 · 慢节奏',
    mood: 'warm',
    bgImage: 'https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=400&q=80',
  },
  {
    id: 'food' as SceneType,
    emoji: '🍜',
    name: '美食记录',
    description: '活泼 · 中等节奏',
    mood: 'energetic',
    bgImage: 'https://images.unsplash.com/photo-1504674900247-0877df9cc836?w=400&q=80',
  },
  {
    id: 'daily' as SceneType,
    emoji: '📷',
    name: '日常碎片',
    description: '文艺 · 随性',
    mood: 'chill',
    bgImage: 'https://images.unsplash.com/photo-1501854140801-50d01698950b?w=400&q=80',
  },
  {
    id: 'baby' as SceneType,
    emoji: '👶',
    name: '宝宝成长',
    description: '温馨 · 慢节奏',
    mood: 'playful',
    bgImage: 'https://images.unsplash.com/photo-1555252333-9f8e92e65df9?w=400&q=80',
  },
];
