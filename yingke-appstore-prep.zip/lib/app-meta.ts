import packageJson from '@/package.json';

const fallbackAppUrl = process.env.NEXT_PUBLIC_APP_URL ?? 'http://localhost:3000';

export const appMeta = {
  name: '映刻 YingKe',
  shortName: '映刻',
  description: '选几张照片，AI 帮你生成更有氛围感的生活 Vlog。',
  legalEntity: process.env.NEXT_PUBLIC_LEGAL_ENTITY ?? '映刻 YingKe 团队',
  supportEmail: process.env.NEXT_PUBLIC_SUPPORT_EMAIL ?? 'support@example.com',
  supportWebsite: process.env.NEXT_PUBLIC_SUPPORT_WEBSITE ?? `${fallbackAppUrl}/support`,
  appUrl: fallbackAppUrl,
  iosBundleId: process.env.NEXT_PUBLIC_IOS_BUNDLE_ID ?? 'com.yingke.app',
  version: process.env.NEXT_PUBLIC_APP_VERSION ?? packageJson.version,
};
