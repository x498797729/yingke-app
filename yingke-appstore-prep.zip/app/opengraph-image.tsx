import { ImageResponse } from "next/og";

export const size = {
  width: 1200,
  height: 630,
};

export const contentType = "image/png";

export default function OpenGraphImage() {
  return new ImageResponse(
    (
      <div
        style={{
          display: "flex",
          height: "100%",
          width: "100%",
          background:
            "radial-gradient(circle at top left, #fff3ea 0%, #ffe4d6 28%, #f4b392 55%, #db7d49 100%)",
          color: "#1a1c1b",
          fontFamily: "system-ui, sans-serif",
          padding: "56px 60px",
          position: "relative",
        }}
      >
        <div
          style={{
            display: "flex",
            flexDirection: "column",
            justifyContent: "space-between",
            height: "100%",
            width: "100%",
            borderRadius: 40,
            background: "rgba(255,255,255,0.72)",
            boxShadow: "0 20px 60px rgba(90, 35, 6, 0.12)",
            padding: "54px 56px",
          }}
        >
          <div
            style={{
              display: "flex",
              alignItems: "center",
              gap: 18,
            }}
          >
            <div
              style={{
                display: "flex",
                height: 88,
                width: 88,
                alignItems: "center",
                justifyContent: "center",
                borderRadius: 28,
                background:
                  "linear-gradient(145deg, #fff7f1 0%, #ffd5c0 45%, #eb8e5b 100%)",
                color: "#8c2f00",
                fontSize: 36,
                fontWeight: 800,
              }}
            >
              YK
            </div>
            <div
              style={{
                display: "flex",
                flexDirection: "column",
                gap: 4,
              }}
            >
              <div style={{ fontSize: 28, color: "#8a7268" }}>映刻 YingKe</div>
              <div style={{ fontSize: 52, fontWeight: 800 }}>AI Vlog 创作工具</div>
            </div>
          </div>

          <div
            style={{
              display: "flex",
              flexDirection: "column",
              gap: 24,
              maxWidth: 850,
            }}
          >
            <div
              style={{
                fontSize: 78,
                fontWeight: 800,
                lineHeight: 1.04,
                letterSpacing: "-0.04em",
              }}
            >
              选几张照片，
              <br />
              AI 帮你生成生活感短片
            </div>
            <div style={{ fontSize: 32, color: "#57423a", lineHeight: 1.45 }}>
              从旅行、日常、聚会到探店，3 步完成选图、选风格、生成预览。
            </div>
          </div>
        </div>
      </div>
    ),
    size,
  );
}
