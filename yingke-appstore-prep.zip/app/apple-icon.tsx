import { ImageResponse } from "next/og";

export const size = {
  width: 180,
  height: 180,
};

export const contentType = "image/png";

export default function AppleIcon() {
  return new ImageResponse(
    (
      <div
        style={{
          display: "flex",
          height: "100%",
          width: "100%",
          alignItems: "center",
          justifyContent: "center",
          background:
            "linear-gradient(145deg, #fff7f1 0%, #ffe1d2 45%, #f39a6a 100%)",
          color: "#8c2f00",
          fontFamily: "system-ui, sans-serif",
        }}
      >
        <div
          style={{
            display: "flex",
            height: 108,
            width: 108,
            borderRadius: 38,
            alignItems: "center",
            justifyContent: "center",
            background: "rgba(255,255,255,0.92)",
            boxShadow: "0 12px 24px rgba(163, 62, 9, 0.16)",
            fontSize: 54,
            fontWeight: 800,
            letterSpacing: "-0.08em",
          }}
        >
          YK
        </div>
      </div>
    ),
    size,
  );
}
