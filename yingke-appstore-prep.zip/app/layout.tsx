import type { Metadata, Viewport } from "next";
import "./globals.css";

const appBaseUrl = new URL(
  process.env.NEXT_PUBLIC_APP_URL ?? "http://localhost:3000",
);

export const metadata: Metadata = {
  metadataBase: appBaseUrl,
  title: {
    default: "映刻 YingKe",
    template: "%s | 映刻 YingKe",
  },
  description: "选几张照片，AI 帮你生成更有氛围感的生活 Vlog。",
  applicationName: "映刻 YingKe",
  authors: [{ name: "映刻 YingKe" }],
  creator: "映刻 YingKe",
  publisher: "映刻 YingKe",
  generator: "Next.js",
  keywords: [
    "映刻",
    "YingKe",
    "AI Vlog",
    "AI 视频生成",
    "照片成片",
    "短视频创作",
  ],
  referrer: "origin-when-cross-origin",
  alternates: {
    canonical: "/",
  },
  manifest: "/manifest.webmanifest",
  category: "photo",
  formatDetection: {
    email: false,
    address: false,
    telephone: false,
  },
  appleWebApp: {
    capable: true,
    title: "映刻 YingKe",
    statusBarStyle: "black-translucent",
  },
  openGraph: {
    type: "website",
    locale: "zh_CN",
    url: "/",
    siteName: "映刻 YingKe",
    title: "映刻 YingKe",
    description: "选几张照片，AI 帮你生成更有氛围感的生活 Vlog。",
    images: [
      {
        url: "/opengraph-image",
        width: 1200,
        height: 630,
        alt: "映刻 YingKe 分享图",
      },
    ],
  },
  twitter: {
    card: "summary_large_image",
    title: "映刻 YingKe",
    description: "选几张照片，AI 帮你生成更有氛围感的生活 Vlog。",
    images: ["/twitter-image"],
  },
};

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  maximumScale: 1,
  viewportFit: "cover",
  themeColor: "#f9f9f6",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="zh-CN" className="h-full">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700&family=Noto+Sans+SC:wght@300;400;500;600;700&display=swap" rel="stylesheet" />
        <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:wght,FILL@100..700,0..1&display=swap" rel="stylesheet"/>
      </head>
      <body className="h-full bg-[#f9f9f6]">
        <div className="mobile-container">
          {children}
        </div>
      </body>
    </html>
  );
}
