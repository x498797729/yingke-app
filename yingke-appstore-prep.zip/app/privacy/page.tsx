import type { Metadata } from "next";
import Link from "next/link";
import { appMeta } from "@/lib/app-meta";

export const metadata: Metadata = {
  title: "隐私政策",
  description: "映刻 YingKe 隐私政策",
};

const sections = [
  {
    title: "1. 我们收集什么",
    body:
      "你在使用映刻时主动上传的照片、生成后的缩略图和视频、以及与你的创作流程直接相关的基础项目数据，可能会被保存用于继续编辑、展示作品和排查问题。",
  },
  {
    title: "2. 我们如何使用这些信息",
    body:
      "这些信息仅用于完成你发起的内容生成、展示作品列表、提供基础客户支持，以及改进生成稳定性。未经你的明确授权，不会将你的素材用于公开训练或对外传播。",
  },
  {
    title: "3. 数据存储与安全",
    body:
      "当前版本的数据会存放在项目自己的服务端与数据库中。正式上架前，你应补充真实的数据保留周期、删除机制、对象存储方案和访问控制策略。",
  },
  {
    title: "4. 你的权利",
    body:
      "你可以请求删除作品、清理账号相关数据，或要求说明数据用途。正式商用前，建议补充一个可联系到开发者的邮箱或工单入口。",
  },
  {
    title: "5. 需要你在上架前补充的内容",
    body:
      "请把本页中的占位说明替换成你的真实公司或个人主体、联系方式、服务器地区、第三方服务清单，以及实际的数据删除流程。",
  },
];

export default function PrivacyPage() {
  return (
    <main className="min-h-dvh bg-[var(--surface)] px-6 py-8 text-[var(--on-surface)]">
      <div className="mx-auto flex max-w-3xl flex-col gap-6">
        <Link
          href="/"
          className="w-fit rounded-full bg-white px-4 py-2 text-sm font-medium text-[var(--on-surface-variant)] shadow-sm"
        >
          返回映刻
        </Link>

        <header className="rounded-[28px] bg-white p-6 shadow-sm">
          <p className="text-sm font-medium text-[var(--primary)]">映刻 YingKe</p>
          <h1 className="mt-3 text-3xl font-semibold tracking-tight">隐私政策</h1>
          <p className="mt-3 text-sm leading-6 text-[var(--on-surface-variant)]">
            这是一份适合现阶段 demo 与 TestFlight 使用的隐私政策草稿。真正提交
            App Store 前，请把主体信息、联系方式和数据处理细节补充完整。
          </p>
          <div className="mt-4 rounded-2xl bg-[var(--surface-container-low)] px-4 py-3 text-sm text-[var(--on-surface-variant)]">
            当前主体：{appMeta.legalEntity}
            <br />
            联系邮箱：{appMeta.supportEmail}
          </div>
        </header>

        <section className="grid gap-4">
          {sections.map((section) => (
            <article key={section.title} className="rounded-[24px] bg-white p-6 shadow-sm">
              <h2 className="text-lg font-semibold">{section.title}</h2>
              <p className="mt-3 text-sm leading-7 text-[var(--on-surface-variant)]">
                {section.body}
              </p>
            </article>
          ))}
        </section>
      </div>
    </main>
  );
}
