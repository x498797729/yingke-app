'use client';

import { useEffect, useRef, useState } from 'react';
import { useRouter } from 'next/navigation';
import { motion, AnimatePresence } from 'framer-motion';
import { getGreeting } from '@/lib/utils';
import { SCENES, worksStore, store, CompletedWork } from '@/lib/store';
import { ImageWithSkeleton } from '@/components/image-with-skeleton';
import { type ApiProjectRecord, mapProjectToCompletedWork } from '@/lib/project-client';

const FALLBACK_WORKS = [
  {
    id: 'f1',
    title: '杭州西湖一日',
    thumbnailUrl: 'https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=300&q=80',
    duration: '0:28',
    sceneName: '旅行日记',
    videoUrl: '',
    createdAt: 0,
    sceneId: 'travel' as const,
  },
  {
    id: 'f2',
    title: '夏末年华',
    thumbnailUrl: 'https://images.unsplash.com/photo-1504674900247-0877df9cc836?w=300&q=80',
    duration: '0:34',
    sceneName: '美食记录',
    videoUrl: '',
    createdAt: 0,
    sceneId: 'food' as const,
  },
  {
    id: 'f3',
    title: '日常的温柔',
    thumbnailUrl: 'https://images.unsplash.com/photo-1501854140801-50d01698950b?w=300&q=80',
    duration: '0:21',
    sceneName: '日常碎片',
    videoUrl: '',
    createdAt: 0,
    sceneId: 'daily' as const,
  },
];

const SCENE_ICONS: Record<string, string> = {
  travel: 'map',
  food: 'restaurant',
  daily: 'auto_awesome',
  baby: 'child_care',
};

const SCENE_GRADIENTS: Record<string, string> = {
  travel: 'from-[#fef4ec] to-[#fddec2]',
  food:   'from-[#fef0f0] to-[#fdd0d0]',
  daily:  'from-[#f2effe] to-[#ddd2fe]',
  baby:   'from-[#edfbf4] to-[#c4f0da]',
};

const SCENE_ICON_COLORS: Record<string, string> = {
  travel: '#d05a10',
  food:   '#c0282d',
  daily:  '#6b41e0',
  baby:   '#1a9e5c',
};

const fadeUp = {
  hidden: { opacity: 0, y: 16 },
  show: (i: number) => ({
    opacity: 1, y: 0,
    transition: { delay: i * 0.07, duration: 0.4, ease: [0.25, 0.1, 0.25, 1] as const },
  }),
};

export default function HomePage() {
  const router = useRouter();
  const greeting = getGreeting();
  const [works, setWorks] = useState<CompletedWork[]>([]);
  const [hasPendingVideo, setHasPendingVideo] = useState(false);
  const [imgLoaded, setImgLoaded] = useState(false);
  const [ripple, setRipple] = useState<{ x: number; y: number; id: number } | null>(null);

  // Refs for scroll-driven parallax (no re-render)
  const heroImgRef = useRef<HTMLImageElement>(null);
  const heroOverlayRef = useRef<HTMLDivElement>(null);
  const greetingRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const real = worksStore.getAll();
    setWorks(real.length > 0 ? real : (FALLBACK_WORKS as unknown as CompletedWork[]));
    const state = store.get();
    setHasPendingVideo(!!state.generatedVideoUrl);

    fetch('/api/projects?limit=20')
      .then(async (response) => {
        if (!response.ok) throw new Error('load projects failed');
        return (await response.json()) as {
          ok: boolean;
          projects?: ApiProjectRecord[];
        };
      })
      .then((data) => {
        const remoteWorks =
          data.projects
            ?.map(mapProjectToCompletedWork)
            .filter((work): work is CompletedWork => Boolean(work))
            .sort((a, b) => b.createdAt - a.createdAt) ?? [];

        if (remoteWorks.length > 0) {
          setWorks(remoteWorks);
        }
      })
      .catch(() => {});
  }, []);

  // Scroll-driven parallax + scale
  useEffect(() => {
    const scrollEl = document.getElementById('tab-scroll');
    if (!scrollEl) return;

    let rafId: number;
    const onScroll = () => {
      rafId = requestAnimationFrame(() => {
        const y = scrollEl.scrollTop;

        // Image: parallax (moves up slower) + subtle zoom in
        if (heroImgRef.current) {
          const translateY = y * 0.38;
          const scale = 1 + y * 0.00025;
          heroImgRef.current.style.transform =
            `translateY(${translateY}px) scale(${scale})`;
          heroImgRef.current.style.opacity = `${Math.max(0.3, 1 - y / 280)}`;
        }

        // Greeting text: slides up faster + fades out (depth feel)
        if (greetingRef.current) {
          const ty = -(y * 0.18);
          const op = Math.max(0, 1 - y / 120);
          greetingRef.current.style.transform = `translateY(${ty}px)`;
          greetingRef.current.style.opacity = `${op}`;
        }
      });
    };

    scrollEl.addEventListener('scroll', onScroll, { passive: true });
    return () => {
      scrollEl.removeEventListener('scroll', onScroll);
      cancelAnimationFrame(rafId);
    };
  }, []);

  const handleWorkClick = (work: CompletedWork) => {
    if (work.videoUrl) {
      store.setGeneratedVideoUrl(work.videoUrl);
      store.setScene(work.sceneId);
      store.setProjectId(work.id);
      router.push('/create/preview');
    }
  };

  const handleCreateClick = (e: React.MouseEvent<HTMLButtonElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    setRipple({ x: e.clientX - rect.left, y: e.clientY - rect.top, id: Date.now() });
    setTimeout(() => router.push('/create/photos'), 180);
  };

  return (
    <div className="min-h-full bg-[var(--surface)]">

      {/* ── Hero Section ─────────────────────────────────── */}
      <div className="relative h-[54vh] min-h-[320px] overflow-hidden">

        {/* Landscape photo with cinematic treatment */}
        <img
          ref={heroImgRef}
          src="https://images.unsplash.com/photo-1469474968028-56623f02e42e?w=900&q=85"
          alt=""
          className="absolute inset-0 w-full h-full object-cover transition-opacity duration-700"
          style={{
            filter: 'saturate(1.3) brightness(0.82) contrast(1.08) sepia(0.12)',
            opacity: imgLoaded ? 1 : 0,
            willChange: 'transform, opacity',
            transformOrigin: 'center center',
          }}
          onLoad={() => setImgLoaded(true)}
        />

        {/* Skeleton before image loads */}
        {!imgLoaded && (
          <div className="absolute inset-0 bg-[var(--surface-container-high)]">
            <div
              className="absolute inset-0"
              style={{
                background: 'linear-gradient(90deg, transparent 0%, rgba(255,255,255,0.25) 50%, transparent 100%)',
                animation: 'shimmer 1.5s infinite',
              }}
            />
          </div>
        )}

        {/* Warm color grading overlay */}
        <div className="absolute inset-0 bg-gradient-to-br from-[#7c2d06]/35 via-[#c2440f]/10 to-transparent mix-blend-multiply" />

        {/* Vignette */}
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,transparent_40%,rgba(0,0,0,0.45)_100%)]" />

        {/* Top-to-bottom header gradient */}
        <div className="absolute inset-x-0 top-0 h-32 bg-gradient-to-b from-black/40 to-transparent" />

        {/* Bottom fade into page surface */}
        <div className="absolute inset-x-0 bottom-0 h-28 bg-gradient-to-t from-[#f9f9f6] to-transparent" />

        {/* ── Header overlay ── */}
        <div className="relative z-10 px-5 pt-12 flex items-center justify-between anim-fade-in" style={{ animationDelay: '0.05s' }}>
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-white/20 backdrop-blur-md border border-white/30 flex items-center justify-center shadow-sm">
              <span className="text-white text-[15px] font-bold">映</span>
            </div>
            <div className="flex flex-col">
              <span className="text-[10px] text-white/60 font-medium uppercase tracking-widest">Digital Atelier</span>
              <h1 className="text-[17px] font-bold text-white leading-tight drop-shadow-sm">映刻 YingKe</h1>
            </div>
          </div>
          <button className="w-10 h-10 flex items-center justify-center rounded-full bg-white/15 backdrop-blur-sm">
            <span className="material-symbols-outlined text-white/80" style={{ fontSize: '22px' }}>more_horiz</span>
          </button>
        </div>

        {/* ── Greeting overlay at bottom of hero ── */}
        <div
          ref={greetingRef}
          className="absolute bottom-10 left-5 right-5 z-10 anim-fade-in-up"
          style={{ animationDelay: '0.1s', willChange: 'transform, opacity' }}
        >
          <p className="text-[12px] text-white/65 font-medium tracking-wide mb-1">{greeting}</p>
          <h2 className="text-[38px] font-bold text-white leading-[1.05] tracking-tight drop-shadow-lg">
            Hi,<br />creator
          </h2>
          <p className="text-[13px] text-white/70 mt-2 font-medium">让 AI 捕捉你今天的灵感</p>
        </div>

        {/* Film grain texture overlay */}
        <div
          className="absolute inset-0 opacity-[0.03] pointer-events-none"
          style={{
            backgroundImage: `url("data:image/svg+xml,%3Csvg viewBox='0 0 200 200' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23n)'/%3E%3C/svg%3E")`,
            backgroundSize: '180px',
          }}
        />
      </div>

      {/* ── Content Sheet (rounded top) ────────────────── */}
      <div className="relative -mt-5 rounded-t-[2rem] bg-gradient-to-b from-[#fdf7f3] via-[#f9f6f3] to-[#f9f9f6] pt-6 pb-4">

        {/* Pending video banner */}
        {hasPendingVideo && (
          <motion.div
            className="mx-5 mb-5 bg-[var(--primary-container)]/10 rounded-2xl px-4 py-3 flex items-center gap-3"
            initial={{ opacity: 0, y: -8 }}
            animate={{ opacity: 1, y: 0 }}
            onClick={() => router.push('/create/preview')}
          >
            <span className="material-symbols-outlined text-[var(--primary-container)] flex-none" style={{ fontSize: '20px', fontVariationSettings: "'FILL' 1" }}>auto_fix_high</span>
            <div className="flex-1">
              <p className="text-[13px] font-semibold text-[var(--on-surface)]">你有一段视频待查看</p>
              <p className="text-[11px] text-[var(--on-surface-variant)] mt-0.5">点击继续预览</p>
            </div>
            <span className="material-symbols-outlined text-[var(--primary-container)]" style={{ fontSize: '18px' }}>chevron_right</span>
          </motion.div>
        )}

        {/* Create New CTA */}
        <div className="px-5 mb-7">
          <motion.button
            onClick={handleCreateClick}
            className="w-full bg-gradient-to-br from-[#a33e09] to-[#e8713c] rounded-[1.75rem] p-7 relative overflow-hidden shadow-lg shadow-orange-300/35"
            whileTap={{ scale: 0.96 }}
            transition={{ type: 'spring', stiffness: 400, damping: 20 }}
          >
            {/* Animated shimmer sweep */}
            <motion.div
              className="absolute inset-0 rounded-[1.75rem]"
              style={{
                background: 'linear-gradient(105deg, transparent 30%, rgba(255,255,255,0.18) 50%, transparent 70%)',
                backgroundSize: '200% 100%',
              }}
              animate={{ backgroundPosition: ['200% 0', '-100% 0'] }}
              transition={{ duration: 2.8, repeat: Infinity, repeatDelay: 1.5, ease: 'easeInOut' }}
            />
            {/* Background texture circles */}
            <div className="absolute -right-6 -top-6 w-32 h-32 rounded-full bg-white/10" />
            <div className="absolute -left-4 -bottom-4 w-24 h-24 rounded-full bg-black/8" />
            {/* Ripple on click */}
            <AnimatePresence>
              {ripple && (
                <motion.span
                  key={ripple.id}
                  className="absolute rounded-full bg-white/30 pointer-events-none"
                  style={{ left: ripple.x, top: ripple.y, x: '-50%', y: '-50%' }}
                  initial={{ width: 0, height: 0, opacity: 0.6 }}
                  animate={{ width: 500, height: 500, opacity: 0 }}
                  exit={{ opacity: 0 }}
                  transition={{ duration: 0.55, ease: 'easeOut' }}
                />
              )}
            </AnimatePresence>
            <div className="relative z-10 flex items-center gap-4">
              {/* Icon with pulse ring */}
              <div className="relative flex-none">
                <motion.div
                  className="absolute inset-0 rounded-full bg-white/20"
                  animate={{ scale: [1, 1.35, 1], opacity: [0.5, 0, 0.5] }}
                  transition={{ duration: 2.2, repeat: Infinity, ease: 'easeInOut' }}
                />
                <div className="w-12 h-12 bg-white/20 backdrop-blur-sm rounded-full flex items-center justify-center border border-white/30">
                  <motion.span
                    className="material-symbols-outlined text-white"
                    style={{ fontSize: '22px' }}
                    animate={{ rotate: [0, -8, 8, 0] }}
                    transition={{ duration: 3.5, repeat: Infinity, ease: 'easeInOut', repeatDelay: 1 }}
                  >
                    add_a_photo
                  </motion.span>
                </div>
              </div>
              <div className="text-left">
                <h2 className="text-[20px] font-bold text-white leading-tight">创建新视频</h2>
                <p className="text-[12px] text-white/75 mt-0.5">选几张照片，AI 帮你出片</p>
              </div>
              <motion.div
                className="ml-auto"
                animate={{ x: [0, 4, 0] }}
                transition={{ duration: 1.6, repeat: Infinity, ease: 'easeInOut', repeatDelay: 0.5 }}
              >
                <span className="material-symbols-outlined text-white/60" style={{ fontSize: '20px' }}>arrow_forward_ios</span>
              </motion.div>
            </div>
          </motion.button>
        </div>

        {/* Quick Start */}
        <div className="px-5 mb-7">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-[17px] font-semibold text-[var(--on-surface)]">快速开始</h2>
            <button className="flex items-center gap-0.5 text-[13px] text-[var(--on-surface-variant)]">
              全部 <span className="material-symbols-outlined" style={{ fontSize: '14px' }}>chevron_right</span>
            </button>
          </div>
          <div className="grid grid-cols-2 gap-3">
            {SCENES.map((scene, i) => (
              <motion.button
                key={scene.id}
                onClick={() => router.push(`/create/photos?scene=${scene.id}`)}
                className={`anim-fade-in-up bg-gradient-to-br ${SCENE_GRADIENTS[scene.id] ?? 'from-[#f4f4f1] to-[#e8e6e3]'} p-5 rounded-[1.5rem] flex flex-col gap-3 text-left shadow-sm shadow-black/4`}
                style={{ animationDelay: `${0.05 + i * 0.07}s` }}
                whileTap={{ scale: 0.93, y: 2 }}
                whileHover={{ y: -2, boxShadow: '0 8px 24px rgba(0,0,0,0.1)' }}
              >
                <motion.div
                  className="w-12 h-12 bg-white/70 backdrop-blur-sm rounded-[14px] flex items-center justify-center shadow-sm"
                  whileTap={{ scale: 0.85, rotate: -5 }}
                  transition={{ type: 'spring', stiffness: 500, damping: 20 }}
                >
                  <span
                    className="material-symbols-outlined"
                    style={{ fontSize: '24px', color: SCENE_ICON_COLORS[scene.id] ?? 'var(--primary)', fontVariationSettings: "'FILL' 1" }}
                  >
                    {SCENE_ICONS[scene.id] ?? 'photo_camera'}
                  </span>
                </motion.div>
                <div>
                  <p className="text-[14px] font-bold text-[var(--on-surface)]">{scene.name}</p>
                  <p className="text-[11px] text-[var(--on-surface-variant)] mt-0.5 leading-relaxed">{scene.description}</p>
                </div>
              </motion.button>
            ))}
          </div>
        </div>

        {/* Recent Works */}
        <div className="px-5 pb-4">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-[17px] font-semibold text-[var(--on-surface)]">最近作品</h2>
            <button
              className="flex items-center gap-0.5 text-[13px] text-[var(--on-surface-variant)]"
              onClick={() => router.push('/profile')}
            >
              更多 <span className="material-symbols-outlined" style={{ fontSize: '16px' }}>arrow_forward</span>
            </button>
          </div>
          <div className="flex gap-3 overflow-x-auto -mx-5 px-5 pb-2">
            {works.slice(0, 6).map((work, i) => (
              <motion.button
                key={work.id}
                className="anim-fade-in-up flex-none w-[136px] rounded-[1.25rem] overflow-hidden bg-[var(--surface-container-lowest)] shadow-sm shadow-black/5 text-left"
                style={{ animationDelay: `${0.1 + i * 0.06}s` }}
                whileTap={{ scale: 0.94 }}
                onClick={() => handleWorkClick(work)}
              >
                <div className="relative aspect-[3/4] overflow-hidden">
                  <motion.div
                    className="w-full h-full"
                    whileTap={{ scale: 1.07 }}
                    transition={{ type: 'spring', stiffness: 300, damping: 22 }}
                  >
                    <ImageWithSkeleton src={work.thumbnailUrl} alt={work.title} className="w-full h-full object-cover" />
                  </motion.div>
                  <div className="absolute inset-0 bg-gradient-to-t from-black/40 to-transparent" />
                  <motion.div
                    className="absolute inset-0 flex items-center justify-center"
                    whileTap={{ scale: 1.2 }}
                    transition={{ type: 'spring', stiffness: 500, damping: 20 }}
                  >
                    <div className="w-9 h-9 rounded-full bg-white/20 backdrop-blur-sm flex items-center justify-center">
                      <span className="material-symbols-outlined text-white" style={{ fontSize: '18px', fontVariationSettings: "'FILL' 1" }}>play_circle</span>
                    </div>
                  </motion.div>
                  <div className="absolute bottom-2 right-2 bg-black/50 rounded-full px-2 py-0.5">
                    <span className="text-[10px] text-white font-medium">{work.duration}</span>
                  </div>
                </div>
                <div className="px-3 py-2.5">
                  <p className="text-[12px] font-semibold text-[var(--on-surface)] truncate">{work.title}</p>
                  <p className="text-[11px] text-[var(--on-surface-variant)] mt-0.5">{work.sceneName}</p>
                </div>
              </motion.button>
            ))}
          </div>
        </div>

      </div>
    </div>
  );
}
