'use client';

import { useEffect, useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { motion, AnimatePresence } from 'framer-motion';
import { worksStore, CompletedWork, store } from '@/lib/store';
import { type ApiProjectRecord, mapProjectToCompletedWork } from '@/lib/project-client';

export default function ProfilePage() {
  const router = useRouter();
  const [works, setWorks] = useState<CompletedWork[]>([]);
  const [deleteId, setDeleteId] = useState<string | null>(null);

  useEffect(() => {
    const localWorks = worksStore.getAll();
    setWorks(localWorks);

    fetch('/api/projects?limit=50')
      .then(async (response) => {
        if (!response.ok) throw new Error('load projects failed');
        return (await response.json()) as {
          ok: boolean;
          projects?: ApiProjectRecord[];
        };
      })
      .then((data) => {
        const remoteWorks =
          data.projects
            ?.map(mapProjectToCompletedWork)
            .filter((work): work is CompletedWork => Boolean(work))
            .sort((a, b) => b.createdAt - a.createdAt) ?? [];

        if (remoteWorks.length > 0) {
          setWorks(remoteWorks);
        }
      })
      .catch(() => {});
  }, []);

  const handleDelete = (id: string) => {
    if (/^\d+$/.test(id)) {
      fetch(`/api/projects?id=${id}`, { method: 'DELETE' })
        .then(() => {
          setWorks((prev) => prev.filter((work) => work.id !== id));
          setDeleteId(null);
        })
        .catch(() => {
          setDeleteId(null);
        });
      return;
    }

    worksStore.remove(id);
    setWorks(worksStore.getAll());
    setDeleteId(null);
  };

  const handlePlay = (work: CompletedWork) => {
    if (!work.videoUrl) return;
    store.setGeneratedVideoUrl(work.videoUrl);
    store.setScene(work.sceneId);
    store.setProjectId(work.id);
    router.push('/create/preview');
  };

  const totalWorks = works.length;

  return (
    <div className="min-h-full bg-[var(--surface)]">
      {/* Header — warm gradient band */}
      <div className="bg-gradient-to-b from-[#fef2e6] via-[#fdf5ee] to-[#f9f9f6] px-5 pt-12 pb-6">
        <motion.div
          className="flex items-center justify-between mb-6"
          initial={{ opacity: 0, y: -12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4, ease: [0.22, 1, 0.36, 1] }}
        >
          <h1 className="text-[28px] font-bold text-[var(--on-surface)]">我的</h1>
          <motion.button
            className="w-9 h-9 flex items-center justify-center rounded-full bg-white/60 backdrop-blur-sm shadow-sm shadow-orange-100/60"
            whileTap={{ scale: 0.88, rotate: 30 }}
            transition={{ type: 'spring', stiffness: 500, damping: 20 }}
          >
            <span className="material-symbols-outlined" style={{ fontSize: '18px', color: 'var(--on-surface-variant)', fontVariationSettings: "'FILL' 0" }}>settings</span>
          </motion.button>
        </motion.div>

        {/* User card */}
        <motion.div
          className="flex items-center gap-4"
          initial={{ opacity: 0, x: -16 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.1, duration: 0.45, ease: [0.22, 1, 0.36, 1] }}
        >
          <motion.div
            className="w-16 h-16 rounded-full bg-gradient-to-br from-[#E8713C] to-[#a33e09] flex items-center justify-center shadow-lg shadow-orange-200/50"
            initial={{ scale: 0.6, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ delay: 0.15, type: 'spring', stiffness: 400, damping: 22 }}
          >
            <span className="text-white text-[24px] font-bold">映</span>
          </motion.div>
          <div className="flex-1">
            <p className="text-[18px] font-bold text-[var(--on-surface)]">Creator</p>
            <p className="text-[13px] text-[var(--on-surface-variant)] mt-0.5">用影像记录生活的美好</p>
          </div>
        </motion.div>

        {/* Stats */}
        <div className="flex gap-3 mt-5">
          {[
            { label: '作品', value: totalWorks, gradient: 'from-[#fff4ec] to-[#fde2c8]' },
            { label: '获赞', value: '—',        gradient: 'from-[#fef0f5] to-[#fdd0e4]' },
            { label: '关注', value: '—',        gradient: 'from-[#f2effe] to-[#ddd2fe]' },
          ].map(({ label, value, gradient }, i) => (
            <motion.div
              key={label}
              className={`flex-1 bg-gradient-to-br ${gradient} rounded-2xl py-3.5 text-center shadow-sm shadow-black/4`}
              initial={{ opacity: 0, y: 16, scale: 0.92 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              transition={{ delay: 0.2 + i * 0.07, duration: 0.4, ease: [0.22, 1, 0.36, 1] }}
              whileTap={{ scale: 0.94 }}
            >
              <p className="text-[20px] font-bold text-[var(--on-surface)]">{value}</p>
              <p className="text-[11px] text-[var(--on-surface-variant)] mt-0.5">{label}</p>
            </motion.div>
          ))}
        </div>
      </div>

      {/* Works */}
      <motion.div
        className="px-5 pt-5"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.35, duration: 0.3 }}
      >
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-[17px] font-semibold text-[var(--on-surface)]">我的作品</h2>
          <motion.button
            onClick={() => router.push('/create/photos')}
            className="flex items-center gap-1 text-[12px] font-semibold text-[var(--primary-container)] bg-[var(--primary-container)]/10 px-3 py-1.5 rounded-full"
            whileTap={{ scale: 0.92 }}
          >
            <span className="material-symbols-outlined" style={{ fontSize: '14px', fontVariationSettings: "'FILL' 0" }}>add</span>
            新建
          </motion.button>
        </div>

        {works.length === 0 ? (
          <motion.div
            className="flex flex-col items-center justify-center py-20 text-center"
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4, duration: 0.45, ease: [0.22, 1, 0.36, 1] }}
          >
            <motion.div
              className="w-20 h-20 rounded-3xl bg-[var(--surface-container-low)] flex items-center justify-center mb-4"
              animate={{ rotate: [0, -4, 4, -2, 0] }}
              transition={{ duration: 3.5, repeat: Infinity, repeatDelay: 2, ease: 'easeInOut' }}
            >
              <span className="material-symbols-outlined" style={{ fontSize: '32px', color: 'var(--outline)', fontVariationSettings: "'FILL' 0" }}>movie_filter</span>
            </motion.div>
            <p className="text-[15px] font-semibold text-[var(--on-surface)]">还没有作品</p>
            <p className="text-[13px] text-[var(--on-surface-variant)] mt-1 mb-5">选几张照片，让 AI 帮你出片</p>
            <motion.button
              onClick={() => router.push('/create/photos')}
              className="px-8 py-3 rounded-full bg-gradient-to-r from-[#a33e09] to-[#e8713c] text-white text-[14px] font-bold shadow-md shadow-orange-200/50"
              whileTap={{ scale: 0.95 }}
              whileHover={{ scale: 1.03 }}
            >
              开始创作
            </motion.button>
          </motion.div>
        ) : (
          <div className="grid grid-cols-2 gap-3">
            <AnimatePresence>
              {works.map((work, i) => (
                <motion.div
                  key={work.id}
                  className="rounded-[1.25rem] overflow-hidden bg-[var(--surface-container-lowest)] shadow-sm shadow-black/5"
                  initial={{ opacity: 0, y: 20, scale: 0.92 }}
                  animate={{ opacity: 1, y: 0, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.85 }}
                  transition={{ delay: 0.35 + i * 0.07, duration: 0.4, ease: [0.22, 1, 0.36, 1] }}
                  layout
                  whileTap={{ scale: 0.97 }}
                >
                  <div className="relative aspect-[3/4] overflow-hidden">
                    <motion.img
                      src={work.thumbnailUrl}
                      alt={work.title}
                      className="w-full h-full object-cover"
                      whileTap={{ scale: 1.06 }}
                      transition={{ type: 'spring', stiffness: 400, damping: 25 }}
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent" />

                    {/* Play button */}
                    <motion.button
                      onClick={() => handlePlay(work)}
                      className="absolute inset-0 flex items-center justify-center"
                      whileTap={{ scale: 0.9 }}
                    >
                      <motion.div
                        className="w-10 h-10 rounded-full bg-white/25 backdrop-blur-sm flex items-center justify-center"
                        whileTap={{ scale: 1.2, backgroundColor: 'rgba(255,255,255,0.4)' }}
                        transition={{ type: 'spring', stiffness: 500, damping: 20 }}
                      >
                        <span className="material-symbols-outlined" style={{ fontSize: '18px', color: 'white', fontVariationSettings: "'FILL' 1", marginLeft: '2px' }}>play_arrow</span>
                      </motion.div>
                    </motion.button>

                    {/* Duration */}
                    <div className="absolute bottom-2 left-2 bg-black/50 rounded-full px-2 py-0.5">
                      <span className="text-[10px] text-white font-medium">{work.duration}</span>
                    </div>

                    {/* Delete button */}
                    <motion.button
                      onClick={() => setDeleteId(work.id)}
                      className="absolute top-2 right-2 w-7 h-7 rounded-full bg-black/40 backdrop-blur-sm flex items-center justify-center"
                      whileTap={{ scale: 0.85, backgroundColor: 'rgba(220,38,38,0.6)' }}
                      transition={{ type: 'spring', stiffness: 500, damping: 20 }}
                    >
                      <span className="material-symbols-outlined" style={{ fontSize: '13px', color: 'rgba(255,255,255,0.85)', fontVariationSettings: "'FILL' 0" }}>delete</span>
                    </motion.button>
                  </div>

                  <div className="px-3 py-2.5">
                    <p className="text-[12px] font-semibold text-[var(--on-surface)] truncate">{work.title}</p>
                    <p className="text-[10px] text-[var(--on-surface-variant)] mt-0.5">{work.sceneName}</p>
                  </div>
                </motion.div>
              ))}
            </AnimatePresence>
          </div>
        )}
      </motion.div>

      <motion.div
        className="px-5 pt-6"
        initial={{ opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.5, duration: 0.35 }}
      >
        <div className="rounded-[1.5rem] bg-[var(--surface-container-lowest)] p-4 shadow-sm shadow-black/5">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-[15px] font-semibold text-[var(--on-surface)]">上架准备</p>
              <p className="mt-1 text-[12px] text-[var(--on-surface-variant)]">
                隐私政策、服务协议和帮助页已经放进应用里了
              </p>
            </div>
            <span
              className="material-symbols-outlined text-[var(--primary-container)]"
              style={{ fontSize: '22px', fontVariationSettings: "'FILL' 1" }}
            >
              verified
            </span>
          </div>
          <div className="mt-4 grid gap-2">
            {[
              { href: '/about', label: '关于应用' },
              { href: '/privacy', label: '隐私政策' },
              { href: '/terms', label: '服务协议' },
              { href: '/support', label: '支持与帮助' },
            ].map((item) => (
              <Link
                key={item.href}
                href={item.href}
                className="flex items-center justify-between rounded-2xl bg-[var(--surface-container-low)] px-4 py-3 text-[13px] font-medium text-[var(--on-surface)]"
              >
                {item.label}
                <span className="material-symbols-outlined" style={{ fontSize: '18px' }}>
                  chevron_right
                </span>
              </Link>
            ))}
          </div>
        </div>
      </motion.div>

      {/* bottom padding */}
      <div className="h-8" />

      {/* Delete confirmation sheet */}
      <AnimatePresence>
        {deleteId && (
          <>
            <motion.div
              className="fixed inset-0 bg-black/40 z-40"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setDeleteId(null)}
            />
            <motion.div
              className="fixed bottom-0 left-1/2 -translate-x-1/2 w-full max-w-[390px] z-50 bg-[var(--surface)] rounded-t-[2rem] p-6"
              initial={{ y: '100%' }}
              animate={{ y: 0 }}
              exit={{ y: '100%' }}
              transition={{ type: 'spring', stiffness: 350, damping: 35 }}
            >
              <div className="w-10 h-1 rounded-full bg-[var(--surface-container)] mx-auto mb-5" />
              <p className="text-[17px] font-bold text-[var(--on-surface)] text-center mb-1">删除这段视频？</p>
              <p className="text-[13px] text-[var(--on-surface-variant)] text-center mb-6">删除后不可恢复</p>
              <div className="flex gap-3">
                <motion.button
                  onClick={() => setDeleteId(null)}
                  className="flex-1 py-3.5 rounded-2xl bg-[var(--surface-container-low)] text-[15px] font-semibold text-[var(--on-surface-variant)]"
                  whileTap={{ scale: 0.96 }}
                >
                  取消
                </motion.button>
                <motion.button
                  onClick={() => handleDelete(deleteId)}
                  className="flex-1 py-3.5 rounded-2xl bg-red-500 text-[15px] font-bold text-white"
                  whileTap={{ scale: 0.96 }}
                >
                  删除
                </motion.button>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>

    </div>
  );
}
