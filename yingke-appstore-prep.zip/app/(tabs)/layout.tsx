import { BottomTab } from '@/components/bottom-tab';

export default function TabsLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="flex flex-col h-full">
      <div id="tab-scroll" className="flex-1 overflow-y-auto overscroll-none">{children}</div>
      <BottomTab />
    </div>
  );
}
