'use client';

import { useRouter } from 'next/navigation';
import { motion } from 'framer-motion';
const TRENDING = [
  { id: '1', title: '云南大理三日', author: '@旅行的苏苏', views: '12.4w', img: 'https://images.unsplash.com/photo-1470770903676-69b98201ea1c?w=300&q=80', scene: '旅行日记', duration: '0:32' },
  { id: '2', title: '周末探店指南', author: '@吃货小林', views: '8.9w', img: 'https://images.unsplash.com/photo-1482049016688-2d3e1b311543?w=300&q=80', scene: '美食记录', duration: '0:28' },
  { id: '3', title: '宝贝第一步', author: '@幸福妈妈', views: '23.1w', img: 'https://images.unsplash.com/photo-1555252333-9f8e92e65df9?w=300&q=80', scene: '宝宝成长', duration: '0:45' },
  { id: '4', title: '秋天的公园', author: '@日常碎片er', views: '5.6w', img: 'https://images.unsplash.com/photo-1501854140801-50d01698950b?w=300&q=80', scene: '日常碎片', duration: '0:22' },
  { id: '5', title: '海边日落', author: '@向海而生', views: '31.2w', img: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=300&q=80', scene: '旅行日记', duration: '0:38' },
  { id: '6', title: '家常便饭也浪漫', author: '@小厨娘', views: '4.2w', img: 'https://images.unsplash.com/photo-1498837167922-ddd27525d352?w=300&q=80', scene: '美食记录', duration: '0:29' },
];

export default function ExplorePage() {
  const router = useRouter();

  return (
    <div className="min-h-full bg-[var(--surface)]">
      {/* Header — gradient band */}
      <div className="bg-gradient-to-b from-[#fef2e6] via-[#fdf5ee] to-[#f9f9f6] px-5 pt-12 pb-5">
        <motion.h1
          className="text-[28px] font-bold text-[var(--on-surface)]"
          initial={{ opacity: 0, x: -16 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.4, ease: [0.22, 1, 0.36, 1] }}
        >
          探索
        </motion.h1>
        <motion.p
          className="text-[13px] text-[var(--on-surface-variant)] mt-1"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.15, duration: 0.4 }}
        >
          发现精彩 Vlog 创作
        </motion.p>

        {/* Trending badge */}
        <motion.div
          className="mt-4"
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2, duration: 0.4, ease: [0.22, 1, 0.36, 1] }}
        >
          <div className="flex items-center gap-2 bg-gradient-to-r from-[#fff0e6] to-[#fde3cc] rounded-2xl px-4 py-3 shadow-sm shadow-orange-100/60">
            <motion.div
              animate={{ scale: [1, 1.2, 1] }}
              transition={{ duration: 1.8, repeat: Infinity, repeatDelay: 1 }}
            >
              <span className="material-symbols-outlined" style={{ fontSize: '16px', color: 'var(--primary-container)', fontVariationSettings: "'FILL' 1" }}>trending_up</span>
            </motion.div>
            <span className="text-[13px] font-semibold text-[var(--on-surface)]">本周热门</span>
            <span className="ml-auto text-[11px] text-[var(--on-surface-variant)]">每天更新</span>
          </div>
        </motion.div>
      </div>

      {/* Masonry-style grid */}
      <div className="px-4 pt-4">
        <div className="columns-2 gap-3 space-y-3">
          {TRENDING.map((item, i) => (
            <motion.button
              key={item.id}
              className="break-inside-avoid w-full rounded-[1.25rem] overflow-hidden bg-[var(--surface-container-lowest)] shadow-sm shadow-black/5 text-left block"
              initial={{ opacity: 0, y: 24, scale: 0.95 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              transition={{ delay: 0.25 + i * 0.07, duration: 0.45, ease: [0.22, 1, 0.36, 1] }}
              whileTap={{ scale: 0.95 }}
              onClick={() => router.push('/create/photos')}
            >
              <div className="relative" style={{ aspectRatio: i % 3 === 0 ? '3/4' : i % 3 === 1 ? '1/1' : '3/4' }}>
                <img src={item.img} alt={item.title} className="w-full h-full object-cover" />
                <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent" />
                {/* Play */}
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="w-8 h-8 rounded-full bg-white/25 backdrop-blur-sm flex items-center justify-center">
                    <span className="material-symbols-outlined" style={{ fontSize: '14px', color: 'white', fontVariationSettings: "'FILL' 1", marginLeft: '1px' }}>play_arrow</span>
                  </div>
                </div>
                {/* Duration */}
                <div className="absolute bottom-2 right-2 bg-black/50 rounded-full px-1.5 py-0.5">
                  <span className="text-[9px] text-white font-medium">{item.duration}</span>
                </div>
                {/* Scene tag */}
                <div className="absolute top-2 left-2 bg-black/40 backdrop-blur-sm rounded-full px-2 py-0.5">
                  <span className="text-[9px] text-white font-medium">{item.scene}</span>
                </div>
              </div>
              <div className="px-3 py-2.5">
                <p className="text-[12px] font-semibold text-[var(--on-surface)] truncate">{item.title}</p>
                <div className="flex items-center justify-between mt-1">
                  <p className="text-[10px] text-[var(--on-surface-variant)]">{item.author}</p>
                  <p className="text-[10px] text-[var(--outline)]">{item.views} 播放</p>
                </div>
              </div>
            </motion.button>
          ))}
        </div>
      </div>

      {/* CTA */}
      <div className="px-5 pt-8 pb-4">
        <div className="bg-gradient-to-br from-[#fff4ec] via-[#fde8d4] to-[#fddec8] rounded-[1.75rem] px-6 py-6 text-center shadow-sm shadow-orange-100/50">
          <p className="text-[13px] text-[var(--on-surface-variant)] mb-4">用你的照片，创作下一个精彩故事</p>
          <motion.button
            onClick={() => router.push('/create/photos')}
            className="px-8 py-3 rounded-full bg-gradient-to-r from-[#a33e09] to-[#e8713c] text-white text-[14px] font-bold shadow-md shadow-orange-200/50"
            whileTap={{ scale: 0.95 }}
          >
            立刻创作
          </motion.button>
        </div>
      </div>

    </div>
  );
}
