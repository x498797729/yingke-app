import { ImageResponse } from "next/og";

export const size = {
  width: 1200,
  height: 630,
};

export const contentType = "image/png";

export default function TwitterImage() {
  return new ImageResponse(
    (
      <div
        style={{
          display: "flex",
          height: "100%",
          width: "100%",
          background:
            "linear-gradient(135deg, #fff8f4 0%, #ffe9de 35%, #f6ba98 100%)",
          color: "#1a1c1b",
          fontFamily: "system-ui, sans-serif",
          padding: "56px",
        }}
      >
        <div
          style={{
            display: "flex",
            flex: 1,
            borderRadius: 42,
            background: "rgba(255,255,255,0.8)",
            padding: "54px",
            flexDirection: "column",
            justifyContent: "space-between",
          }}
        >
          <div
            style={{
              display: "flex",
              alignItems: "center",
              gap: 18,
              fontSize: 34,
              color: "#8c2f00",
              fontWeight: 700,
            }}
          >
            <div
              style={{
                display: "flex",
                height: 72,
                width: 72,
                borderRadius: 24,
                background: "#ffffff",
                alignItems: "center",
                justifyContent: "center",
                boxShadow: "0 10px 24px rgba(163, 62, 9, 0.12)",
              }}
            >
              YK
            </div>
            映刻 YingKe
          </div>

          <div
            style={{
              display: "flex",
              flexDirection: "column",
              gap: 20,
              maxWidth: 820,
            }}
          >
            <div style={{ fontSize: 76, fontWeight: 800, lineHeight: 1.06 }}>
              把照片变成更好看的 Vlog
            </div>
            <div style={{ fontSize: 32, color: "#57423a", lineHeight: 1.45 }}>
              为移动端分享、PWA 安装和后续 iOS 封装准备好的品牌与元信息基础。
            </div>
          </div>
        </div>
      </div>
    ),
    size,
  );
}
