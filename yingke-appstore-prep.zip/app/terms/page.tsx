import type { Metadata } from "next";
import Link from "next/link";
import { appMeta } from "@/lib/app-meta";

export const metadata: Metadata = {
  title: "服务协议",
  description: "映刻 YingKe 服务协议",
};

const sections = [
  {
    title: "1. 服务说明",
    body:
      "映刻是一款帮助用户把照片整理并生成生活感短视频的创作工具。当前版本仍处于早期阶段，功能与生成结果会持续调整。",
  },
  {
    title: "2. 用户内容",
    body:
      "你需要确保上传的照片、音频和其他素材拥有合法使用权，不侵犯他人的肖像权、著作权或其他合法权益。",
  },
  {
    title: "3. 禁止行为",
    body:
      "不得利用本服务上传违法、侵权、骚扰、欺诈或其他违反平台规则的内容，也不得尝试攻击、滥用或绕过系统限制。",
  },
  {
    title: "4. 免责声明",
    body:
      "AI 生成结果可能存在偏差、错误或不稳定情况。你应在发布前自行审核内容是否准确、合规并适合公开传播。",
  },
  {
    title: "5. 上架前待补充项目",
    body:
      "请在正式提交审核前补充收费说明、退款规则、账号注销路径、未成年人条款，以及与你未来订阅方案匹配的内购条款。",
  },
];

export default function TermsPage() {
  return (
    <main className="min-h-dvh bg-[var(--surface)] px-6 py-8 text-[var(--on-surface)]">
      <div className="mx-auto flex max-w-3xl flex-col gap-6">
        <Link
          href="/"
          className="w-fit rounded-full bg-white px-4 py-2 text-sm font-medium text-[var(--on-surface-variant)] shadow-sm"
        >
          返回映刻
        </Link>

        <header className="rounded-[28px] bg-white p-6 shadow-sm">
          <p className="text-sm font-medium text-[var(--primary)]">映刻 YingKe</p>
          <h1 className="mt-3 text-3xl font-semibold tracking-tight">服务协议</h1>
          <p className="mt-3 text-sm leading-6 text-[var(--on-surface-variant)]">
            这是一版适合当前项目阶段的协议草稿，重点是先把审核需要的页面结构补齐。
            里面涉及商业化和法务的部分，你后面还需要替换成正式版本。
          </p>
          <div className="mt-4 rounded-2xl bg-[var(--surface-container-low)] px-4 py-3 text-sm text-[var(--on-surface-variant)]">
            服务主体：{appMeta.legalEntity}
          </div>
        </header>

        <section className="grid gap-4">
          {sections.map((section) => (
            <article key={section.title} className="rounded-[24px] bg-white p-6 shadow-sm">
              <h2 className="text-lg font-semibold">{section.title}</h2>
              <p className="mt-3 text-sm leading-7 text-[var(--on-surface-variant)]">
                {section.body}
              </p>
            </article>
          ))}
        </section>
      </div>
    </main>
  );
}
