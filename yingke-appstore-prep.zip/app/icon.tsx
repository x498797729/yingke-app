import { ImageResponse } from "next/og";

export const size = {
  width: 512,
  height: 512,
};

export const contentType = "image/png";

export default function Icon() {
  return new ImageResponse(
    (
      <div
        style={{
          display: "flex",
          height: "100%",
          width: "100%",
          alignItems: "center",
          justifyContent: "center",
          background:
            "linear-gradient(145deg, #fff7f1 0%, #ffe1d2 45%, #f39a6a 100%)",
          color: "#8c2f00",
          fontFamily: "system-ui, sans-serif",
          position: "relative",
        }}
      >
        <div
          style={{
            position: "absolute",
            inset: 30,
            borderRadius: 120,
            border: "8px solid rgba(255,255,255,0.45)",
          }}
        />
        <div
          style={{
            display: "flex",
            height: 252,
            width: 252,
            borderRadius: 88,
            alignItems: "center",
            justifyContent: "center",
            background: "rgba(255,255,255,0.88)",
            boxShadow: "0 24px 60px rgba(163, 62, 9, 0.18)",
            fontSize: 120,
            fontWeight: 800,
            letterSpacing: "-0.08em",
          }}
        >
          YK
        </div>
      </div>
    ),
    size,
  );
}
