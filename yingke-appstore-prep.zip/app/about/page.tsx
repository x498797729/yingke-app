import type { Metadata } from 'next';
import Link from 'next/link';
import { appMeta } from '@/lib/app-meta';

export const metadata: Metadata = {
  title: '关于应用',
  description: '映刻 YingKe 应用信息与上架准备',
};

const items = [
  { label: '应用名称', value: appMeta.name },
  { label: '版本号', value: appMeta.version },
  { label: 'iOS Bundle ID', value: appMeta.iosBundleId },
  { label: '主体信息', value: appMeta.legalEntity },
  { label: '支持邮箱', value: appMeta.supportEmail },
];

export default function AboutPage() {
  return (
    <main className="min-h-dvh bg-[var(--surface)] px-6 py-8 text-[var(--on-surface)]">
      <div className="mx-auto flex max-w-3xl flex-col gap-6">
        <Link
          href="/profile"
          className="w-fit rounded-full bg-white px-4 py-2 text-sm font-medium text-[var(--on-surface-variant)] shadow-sm"
        >
          返回我的
        </Link>

        <header className="rounded-[28px] bg-white p-6 shadow-sm">
          <p className="text-sm font-medium text-[var(--primary)]">映刻 YingKe</p>
          <h1 className="mt-3 text-3xl font-semibold tracking-tight">关于应用</h1>
          <p className="mt-3 text-sm leading-7 text-[var(--on-surface-variant)]">
            这里集中放当前版本、bundle id、联系信息和法务入口，方便你后续做
            TestFlight、Xcode 配置和 App Store Connect 信息填写。
          </p>
        </header>

        <section className="rounded-[28px] bg-white p-6 shadow-sm">
          <h2 className="text-lg font-semibold">应用信息</h2>
          <div className="mt-4 grid gap-3">
            {items.map((item) => (
              <div
                key={item.label}
                className="rounded-2xl bg-[var(--surface-container-low)] px-4 py-3"
              >
                <p className="text-xs font-medium text-[var(--on-surface-variant)]">
                  {item.label}
                </p>
                <p className="mt-1 text-sm font-semibold text-[var(--on-surface)]">
                  {item.value}
                </p>
              </div>
            ))}
          </div>
        </section>

        <section className="rounded-[28px] bg-white p-6 shadow-sm">
          <h2 className="text-lg font-semibold">审核常用入口</h2>
          <div className="mt-4 grid gap-2">
            {[
              { href: '/privacy', label: '隐私政策' },
              { href: '/terms', label: '服务协议' },
              { href: '/support', label: '支持与帮助' },
            ].map((item) => (
              <Link
                key={item.href}
                href={item.href}
                className="flex items-center justify-between rounded-2xl bg-[var(--surface-container-low)] px-4 py-3 text-sm font-medium"
              >
                {item.label}
                <span className="material-symbols-outlined" style={{ fontSize: '18px' }}>
                  open_in_new
                </span>
              </Link>
            ))}
          </div>
        </section>
      </div>
    </main>
  );
}
