'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { motion } from 'framer-motion';
import { store, SCENES, SceneType } from '@/lib/store';
import { cn } from '@/lib/utils';

const SCENE_META: Record<string, { icon: string; subtitle: string }> = {
  travel: { icon: 'movie_filter', subtitle: 'Cinematic' },
  food: { icon: 'restaurant', subtitle: 'Lifestyle' },
  daily: { icon: 'auto_fix_high', subtitle: 'Artistic' },
  baby: { icon: 'favorite', subtitle: 'Emotional' },
};

export default function ScenePickerPage() {
  const router = useRouter();
  const [selected, setSelected] = useState<SceneType | null>(null);
  const [photoCount, setPhotoCount] = useState(0);

  useEffect(() => {
    const state = store.get();
    setPhotoCount(state.photos.length);
    if (state.scene) setSelected(state.scene);
    if (state.photos.length === 0) router.replace('/create/photos');
  }, [router]);

  const handleGenerate = () => {
    if (!selected) return;
    store.setScene(selected);
    router.push('/create/generating');
  };

  return (
    <div className="flex flex-col h-screen bg-[var(--surface)]">
      {/* Nav */}
      <div className="glass flex items-center justify-between px-5 py-4 sticky top-0 z-50">
        <motion.button
          onClick={() => router.back()}
          className="w-9 h-9 flex items-center justify-center rounded-full bg-[var(--surface-container-low)]"
          whileTap={{ scale: 0.9 }}
        >
          <span className="material-symbols-outlined text-[var(--on-surface)]" style={{ fontSize: '22px' }}>arrow_back_ios</span>
        </motion.button>
        <span className="text-[15px] font-semibold text-[var(--on-surface)]">选择风格</span>
        <motion.button
          onClick={handleGenerate}
          disabled={!selected}
          whileTap={selected ? { scale: 0.9 } : {}}
          className={cn(
            'text-[14px] font-bold px-5 py-2 rounded-full transition-all',
            selected
              ? 'bg-gradient-to-tr from-[#a33e09] to-[#e8713c] text-white shadow-lg shadow-primary/20'
              : 'text-[var(--outline)] cursor-not-allowed bg-transparent'
          )}
        >
          生成
        </motion.button>
      </div>

      {/* Subtitle */}
      <motion.div
        className="px-5 pt-5 pb-3"
        initial={{ opacity: 0, y: 8 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.35 }}
      >
        <p className="text-[22px] font-bold text-[var(--on-surface)]">让 AI 为你的回忆</p>
        <p className="text-[22px] font-bold text-[var(--primary-container)]">注入电影感</p>
        <p className="text-[13px] text-[var(--on-surface-variant)] mt-2">
          已选 <span className="font-semibold text-[var(--on-surface)]">{photoCount}</span> 张 · 选一个风格，AI 帮你编排
        </p>
      </motion.div>

      {/* Scene cards */}
      <div className="flex-1 overflow-y-auto px-5 py-2 space-y-4">
        {SCENES.map((scene, i) => {
          const isSelected = selected === scene.id;
          return (
            <motion.button
              key={scene.id}
              onClick={() => setSelected(scene.id)}
              className="w-full relative overflow-hidden rounded-[1.5rem] text-left"
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.07, duration: 0.35 }}
              whileTap={{ scale: 0.97 }}
              style={{
                boxShadow: isSelected
                  ? '0 0 0 3px var(--primary-container), 0 20px 40px rgba(163, 62, 9, 0.12)'
                  : '0 2px 8px rgba(0,0,0,0.06)',
                transform: isSelected ? 'scale(1.01)' : 'scale(1)',
                transition: 'transform 0.2s, box-shadow 0.2s',
              }}
            >
              <div className="aspect-[4/5] relative overflow-hidden">
                <img src={scene.bgImage} alt={scene.name} className="w-full h-full object-cover" />
                <div className="absolute inset-0 bg-gradient-to-t from-black/65 via-black/10 to-transparent" />
                {/* Bottom content */}
                <div className="absolute bottom-0 left-0 right-0 p-6 text-white">
                  <div className="flex items-center gap-2 mb-2">
                    <span className="material-symbols-outlined text-white" style={{ fontSize: '20px', fontVariationSettings: "'FILL' 1" }}>
                      {SCENE_META[scene.id]?.icon ?? 'photo_camera'}
                    </span>
                    <span className="text-[10px] font-bold tracking-widest uppercase opacity-80">{SCENE_META[scene.id]?.subtitle}</span>
                  </div>
                  <h3 className="text-[24px] font-bold mb-1">{scene.name}</h3>
                  <p className="text-[13px] text-white/80">{scene.description}</p>
                </div>
                {/* Selected badge */}
                {isSelected && (
                  <div className="absolute top-5 right-5 w-9 h-9 rounded-full bg-[var(--primary-container)] flex items-center justify-center shadow-lg">
                    <span className="material-symbols-outlined text-white" style={{ fontSize: '20px' }}>check</span>
                  </div>
                )}
              </div>
            </motion.button>
          );
        })}
      </div>

      {/* Generate button */}
      <motion.div
        className="px-5 pb-10 pt-4"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.3, duration: 0.4 }}
      >
        <motion.button
          onClick={handleGenerate}
          disabled={!selected}
          whileTap={selected ? { scale: 0.97 } : {}}
          className={cn(
            'w-full py-4 rounded-[1.5rem] text-[16px] font-bold transition-all flex items-center justify-center gap-2',
            selected
              ? 'bg-gradient-to-r from-[#a33e09] to-[#e8713c] text-white shadow-lg shadow-orange-200/50'
              : 'bg-[var(--surface-container)] text-[var(--outline)] cursor-not-allowed'
          )}
        >
          <span className="material-symbols-outlined text-white" style={{ fontSize: '18px', fontVariationSettings: "'FILL' 1" }}>auto_fix_high</span>
          {selected ? '开始 AI 生成' : '请先选择一个风格'}
        </motion.button>
      </motion.div>
    </div>
  );
}
