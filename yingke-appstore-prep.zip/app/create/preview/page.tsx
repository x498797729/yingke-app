'use client';

import { useEffect, useRef, useState } from 'react';
import { useRouter } from 'next/navigation';
import { motion, AnimatePresence } from 'framer-motion';
import { store, worksStore, SCENES, SceneType } from '@/lib/store';
import { extractThumbnail, getVideoDuration } from '@/lib/video-utils';
import { generateId, cn } from '@/lib/utils';

type TabKey = 'music' | 'filter' | 'text';

const MUSIC_OPTIONS = [
  { id: 'warm', label: '温暖清晨', sub: 'Warm Morning' },
  { id: 'light', label: '轻盈午后', sub: 'Light Noon' },
  { id: 'lazy', label: '慵懒傍晚', sub: 'Lazy Dusk' },
  { id: 'dream', label: '梦境清晨', sub: 'Dream Dawn' },
];

const FILTER_OPTIONS = [
  { id: 'none', name: '原色', from: 'from-gray-200', to: 'to-gray-300' },
  { id: 'warm', name: '暖调', from: 'from-orange-200', to: 'to-amber-200' },
  { id: 'cool', name: '冷白', from: 'from-blue-100', to: 'to-sky-200' },
  { id: 'film', name: '胶片', from: 'from-amber-200', to: 'to-orange-300' },
];

function parseDurationToSeconds(duration: string) {
  const [minutes = '0', seconds = '0'] = duration.split(':');
  return Number(minutes) * 60 + Number(seconds);
}

export default function PreviewPage() {
  const router = useRouter();
  const videoRef = useRef<HTMLVideoElement>(null);
  const progressRef = useRef<HTMLDivElement>(null);
  const workSavedRef = useRef(false);

  const [videoUrl, setVideoUrl] = useState<string | null>(null);
  const [sceneName, setSceneName] = useState('');
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [isMuted, setIsMuted] = useState(true);
  const [saved, setSaved] = useState(false);
  const [shared, setShared] = useState(false);
  const [activeTab, setActiveTab] = useState<TabKey | null>(null);
  const [selectedMusic, setSelectedMusic] = useState('warm');
  const [selectedFilter, setSelectedFilter] = useState('none');
  const [showControls, setShowControls] = useState(true);
  const hideControlsTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  // Auto-hide controls after 3s
  const resetHideTimer = () => {
    setShowControls(true);
    clearTimeout(hideControlsTimer.current ?? undefined);
    hideControlsTimer.current = setTimeout(() => {
      if (isPlaying) setShowControls(false);
    }, 3000);
  };

  useEffect(() => {
    const state = store.get();
    if (!state.generatedVideoUrl) { router.replace('/create/photos'); return; }
    setVideoUrl(state.generatedVideoUrl);
    const s = SCENES.find((sc) => sc.id === state.scene);
    setSceneName(s?.name ?? '');

    if (!workSavedRef.current && state.generatedVideoUrl && state.scene) {
      workSavedRef.current = true;
      const scene = SCENES.find((sc) => sc.id === state.scene);
      const titleMap: Record<SceneType, string[]> = {
        travel: ['旅途中的光', '远方的风景', '流浪记'],
        food: ['觅食指南', '这口太香了', '美食日记'],
        daily: ['日常碎片', '平凡的美好', '生活随笔'],
        baby: ['宝宝的今天', '成长的印记', '小小世界'],
      };
      const titles = titleMap[state.scene as SceneType] ?? ['我的作品'];
      const title = titles[Math.floor(Math.random() * titles.length)];

      Promise.all([
        extractThumbnail(state.generatedVideoUrl).catch(() => scene?.bgImage ?? ''),
        getVideoDuration(state.generatedVideoUrl).catch(() => '0:30'),
      ]).then(([thumbnailUrl, dur]) => {
        if (state.projectId) {
          fetch('/api/projects', {
            method: 'PUT',
            headers: {
              'Content-Type': 'application/json',
            },
            body: JSON.stringify({
              id: state.projectId,
              status: 'completed',
              title,
              sceneId: state.scene,
              sceneName: scene?.name ?? '',
              thumbnailUrl,
              generatedVideoUrl: state.generatedVideoUrl,
              durationSeconds: parseDurationToSeconds(dur),
            }),
          }).catch(() => {});
        }

        worksStore.add({
          id: generateId(),
          title,
          sceneId: state.scene as SceneType,
          sceneName: scene?.name ?? '',
          thumbnailUrl,
          videoUrl: state.generatedVideoUrl!,
          duration: dur,
          createdAt: Date.now(),
        });
      });
    }
  }, [router]);

  useEffect(() => {
    const video = videoRef.current;
    if (!video || !videoUrl) return;

    const onTime = () => setCurrentTime(video.currentTime);
    const onMeta = () => setDuration(isFinite(video.duration) ? video.duration : 0);
    const onPlay = () => { setIsPlaying(true); resetHideTimer(); };
    const onPause = () => { setIsPlaying(false); setShowControls(true); };
    const onEnded = () => { setIsPlaying(false); setCurrentTime(0); setShowControls(true); };

    video.addEventListener('timeupdate', onTime);
    video.addEventListener('loadedmetadata', onMeta);
    video.addEventListener('durationchange', onMeta);
    video.addEventListener('play', onPlay);
    video.addEventListener('pause', onPause);
    video.addEventListener('ended', onEnded);
    video.play().catch(() => {});

    return () => {
      video.removeEventListener('timeupdate', onTime);
      video.removeEventListener('loadedmetadata', onMeta);
      video.removeEventListener('durationchange', onMeta);
      video.removeEventListener('play', onPlay);
      video.removeEventListener('pause', onPause);
      video.removeEventListener('ended', onEnded);
      clearTimeout(hideControlsTimer.current ?? undefined);
    };
  }, [videoUrl]);

  const togglePlay = () => {
    if (!videoRef.current) return;
    resetHideTimer();
    isPlaying ? videoRef.current.pause() : videoRef.current.play();
  };

  // Tap on progress bar area to seek
  const handleProgressTap = (e: React.PointerEvent<HTMLDivElement>) => {
    if (!progressRef.current || !duration) return;
    const rect = progressRef.current.getBoundingClientRect();
    const ratio = Math.max(0, Math.min(1, (e.clientX - rect.left) / rect.width));
    const t = ratio * duration;
    if (videoRef.current) videoRef.current.currentTime = t;
    setCurrentTime(t);
  };

  const handleSave = async () => {
    if (!videoUrl) return;
    const a = document.createElement('a');
    a.href = videoUrl;
    a.download = `映刻-${sceneName}-${Date.now()}.webm`;
    a.click();
    setSaved(true);
    navigator.vibrate?.(30);
    setTimeout(() => setSaved(false), 3000);
  };

  const handleShare = async () => {
    if (!videoUrl) return;
    if (navigator.share) {
      try {
        const response = await fetch(videoUrl);
        const blob = await response.blob();
        const file = new File([blob], `映刻-${sceneName}.webm`, { type: blob.type });
        if (navigator.canShare?.({ files: [file] })) {
          await navigator.share({ files: [file], title: `映刻 · ${sceneName}`, text: '用映刻 AI 生成的精彩 Vlog ✨' });
        } else {
          await navigator.share({ title: `映刻 · ${sceneName}`, text: '用映刻 AI 生成的精彩 Vlog ✨' });
        }
        setShared(true);
        setTimeout(() => setShared(false), 2000);
      } catch (e) {
        // User cancelled or error — fallback to download
        handleSave();
      }
    } else {
      handleSave();
    }
  };

  const handleFullscreen = () => {
    if (videoRef.current) {
      if (videoRef.current.requestFullscreen) videoRef.current.requestFullscreen();
      else if ((videoRef.current as any).webkitEnterFullscreen) (videoRef.current as any).webkitEnterFullscreen();
    }
  };

  const fmt = (t: number) => {
    if (!isFinite(t) || t === 0) return '0:00';
    return `${Math.floor(t / 60)}:${String(Math.floor(t % 60)).padStart(2, '0')}`;
  };

  const pct = duration > 0 ? Math.min(100, (currentTime / duration) * 100) : 0;

  return (
    <div className="flex flex-col h-screen bg-black">
      {/* Nav overlay */}
      <AnimatePresence>
        {showControls && (
          <motion.div
            className="absolute top-0 left-0 right-0 z-50 flex items-center justify-between px-5 py-4 bg-gradient-to-b from-black/60 to-transparent"
            initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            transition={{ duration: 0.2 }}
          >
            <motion.button
              onClick={() => router.back()}
              className="w-9 h-9 flex items-center justify-center rounded-full bg-white/15 backdrop-blur-sm"
              whileTap={{ scale: 0.9 }}
            >
              <span className="material-symbols-outlined text-white" style={{ fontSize: '22px' }}>arrow_back_ios_new</span>
            </motion.button>
            <span className="text-[15px] font-semibold text-white">预览 + 微调</span>
            <motion.button
              onClick={handleSave}
              className="flex items-center gap-1.5 bg-white/15 backdrop-blur-sm text-white text-[13px] font-semibold px-4 py-2 rounded-full"
              whileTap={{ scale: 0.92 }}
            >
              {saved ? <span className="material-symbols-outlined text-white" style={{ fontSize: '16px' }}>check</span> : <span className="material-symbols-outlined text-white" style={{ fontSize: '16px' }}>download</span>}
              {saved ? '已保存' : '保存'}
            </motion.button>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Video */}
      <div
        className="flex-1 relative bg-black flex items-center justify-center"
        onClick={() => { togglePlay(); resetHideTimer(); }}
      >
        {videoUrl ? (
          <video
            ref={videoRef}
            src={videoUrl}
            muted={isMuted}
            playsInline
            loop
            className="w-full h-full object-contain"
          />
        ) : (
          <div className="w-12 h-12 rounded-full border-2 border-white/30 border-t-white animate-spin" />
        )}

        {/* AI badge */}
        <motion.div
          className="absolute top-20 right-4 bg-black/40 backdrop-blur-sm rounded-full px-2.5 py-1"
          initial={{ opacity: 0, x: 10 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.6 }}
        >
          <span className="material-symbols-outlined text-white/75" style={{ fontSize: '12px', fontVariationSettings: "'FILL' 1" }}>auto_fix_high</span>
          <span className="text-[9px] font-bold text-white/75 tracking-widest"> AI-GENERATED</span>
        </motion.div>

        {/* Play/pause indicator */}
        <AnimatePresence>
          {showControls && !isPlaying && (
            <motion.div
              className="absolute inset-0 flex items-center justify-center pointer-events-none"
              initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
              transition={{ duration: 0.15 }}
            >
              <div className="w-16 h-16 rounded-full bg-white/20 backdrop-blur-sm flex items-center justify-center">
                <span className="material-symbols-outlined" style={{ fontSize: '30px', color: 'white', fontVariationSettings: "'FILL' 1", marginLeft: '3px' }}>play_arrow</span>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Bottom-right controls */}
        <AnimatePresence>
          {showControls && (
            <motion.div
              className="absolute bottom-10 right-4 flex flex-col gap-2"
              initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            >
              <motion.button
                onClick={(e) => { e.stopPropagation(); setIsMuted(!isMuted); }}
                className="w-9 h-9 rounded-full bg-black/40 backdrop-blur-sm flex items-center justify-center"
                whileTap={{ scale: 0.85 }}
              >
                {isMuted
                  ? <span className="material-symbols-outlined text-white" style={{ fontSize: '18px' }}>volume_off</span>
                  : <span className="material-symbols-outlined text-white" style={{ fontSize: '18px' }}>volume_up</span>}
              </motion.button>
              <motion.button
                onClick={(e) => { e.stopPropagation(); handleFullscreen(); }}
                className="w-9 h-9 rounded-full bg-black/40 backdrop-blur-sm flex items-center justify-center"
                whileTap={{ scale: 0.85 }}
              >
                <span className="material-symbols-outlined text-white" style={{ fontSize: '18px' }}>fullscreen</span>
              </motion.button>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Controls panel */}
      <motion.div
        className="bg-[var(--surface)] rounded-t-[2rem] -mt-6 relative z-10 flex flex-col overflow-hidden"
        style={{ maxHeight: '62vh' }}
        initial={{ y: 60, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ delay: 0.15, type: 'spring', stiffness: 300, damping: 30 }}
      >
        {/* Progress bar — large touch target — always visible */}
        <div className="px-5 pt-5 pb-3 flex-none">
          <div className="flex items-center gap-3 mb-3">
            <span className="text-[11px] text-[var(--on-surface-variant)] w-8 text-right font-mono tabular-nums">
              {fmt(currentTime)}
            </span>
            {/* Tap area wraps the bar */}
            <div
              ref={progressRef}
              className="flex-1 relative h-8 flex items-center cursor-pointer"
              onPointerDown={handleProgressTap}
            >
              {/* Track */}
              <div className="w-full h-1.5 bg-[var(--surface-container)] rounded-full overflow-hidden">
                <motion.div
                  className="h-full bg-gradient-to-r from-[#a33e09] to-[#e8713c] rounded-full origin-left"
                  style={{ width: `${pct}%` }}
                />
              </div>
              {/* Thumb dot */}
              <div
                className="absolute top-1/2 -translate-y-1/2 w-3.5 h-3.5 rounded-full bg-[var(--primary-container)] shadow-md transition-all"
                style={{ left: `calc(${pct}% - 7px)` }}
              />
            </div>
            <span className="text-[11px] text-[var(--on-surface-variant)] w-8 font-mono tabular-nums">
              {fmt(duration)}
            </span>
          </div>

          {/* Play control */}
          <div className="flex items-center justify-center gap-5">
            <motion.button
              onClick={() => { if (videoRef.current) videoRef.current.currentTime = Math.max(0, currentTime - 5); }}
              className="w-9 h-9 flex items-center justify-center text-[var(--on-surface-variant)]"
              whileTap={{ scale: 0.85 }}
            >
              <span className="text-[11px] font-bold">-5s</span>
            </motion.button>
            <motion.button
              onClick={togglePlay}
              className="w-12 h-12 rounded-full bg-gradient-to-br from-[#a33e09] to-[#e8713c] flex items-center justify-center shadow-md shadow-orange-200/50"
              whileTap={{ scale: 0.88 }}
            >
              {isPlaying
                ? <span className="material-symbols-outlined" style={{ fontSize: '22px', color: 'white', fontVariationSettings: "'FILL' 1" }}>pause</span>
                : <span className="material-symbols-outlined" style={{ fontSize: '22px', color: 'white', fontVariationSettings: "'FILL' 1", marginLeft: '2px' }}>play_arrow</span>
              }
            </motion.button>
            <motion.button
              onClick={() => { if (videoRef.current) videoRef.current.currentTime = Math.min(duration, currentTime + 5); }}
              className="w-9 h-9 flex items-center justify-center text-[var(--on-surface-variant)]"
              whileTap={{ scale: 0.85 }}
            >
              <span className="text-[11px] font-bold">+5s</span>
            </motion.button>
          </div>
        </div>

        {/* Fine-tune — scrollable area */}
        <div className="px-5 pb-3 overflow-y-auto flex-1 min-h-0">
          <p className="text-[11px] font-semibold text-[var(--on-surface-variant)] mb-3 tracking-[0.12em] uppercase">
            微调（可选）
          </p>
          <div className="flex gap-2.5">
            {([
              { key: 'music' as TabKey, icon: 'music_note', label: '换音乐' },
              { key: 'filter' as TabKey, icon: 'movie_filter', label: '换滤镜' },
              { key: 'text' as TabKey, icon: 'text_fields', label: '改文字' },
            ]).map(({ key, icon, label }) => (
              <motion.button
                key={key}
                onClick={() => setActiveTab(activeTab === key ? null : key)}
                className={cn(
                  'flex-1 flex flex-col items-center gap-1.5 py-3 rounded-[1.25rem] transition-colors',
                  activeTab === key ? 'bg-[var(--primary-container)]/12' : 'bg-[var(--surface-container-low)]'
                )}
                whileTap={{ scale: 0.93 }}
                style={{
                  outline: activeTab === key ? '1.5px solid var(--primary-container)' : 'none',
                  outlineOffset: '-1.5px',
                }}
              >
                <span
                  className="material-symbols-outlined"
                  style={{
                    fontSize: '20px',
                    color: activeTab === key ? 'var(--primary-container)' : 'var(--on-surface-variant)',
                    fontVariationSettings: activeTab === key ? "'FILL' 1" : "'FILL' 0",
                  }}
                >
                  {icon}
                </span>
                <span className={cn('text-[11px] font-semibold', activeTab === key ? 'text-[var(--primary-container)]' : 'text-[var(--on-surface-variant)]')}>
                  {label}
                </span>
              </motion.button>
            ))}
          </div>

          <AnimatePresence>
            {activeTab && (
              <motion.div
                className="mt-3 bg-[var(--surface-container-low)] rounded-[1.25rem] p-4 overflow-hidden"
                initial={{ height: 0, opacity: 0 }}
                animate={{ height: 'auto', opacity: 1 }}
                exit={{ height: 0, opacity: 0 }}
                transition={{ duration: 0.22, ease: [0.25, 0.1, 0.25, 1] }}
              >
                {activeTab === 'music' && (
                  <div>
                    <p className="text-[12px] font-semibold text-[var(--on-surface-variant)] uppercase tracking-wider mb-3">背景音乐</p>
                    <div className="space-y-1.5">
                      {MUSIC_OPTIONS.map((m) => (
                        <button
                          key={m.id}
                          onClick={() => setSelectedMusic(m.id)}
                          className={cn(
                            'w-full text-left px-4 py-2.5 rounded-xl text-[13px] font-medium flex items-center justify-between transition-colors',
                            selectedMusic === m.id
                              ? 'bg-[var(--primary-container)]/15 text-[var(--primary-container)]'
                              : 'bg-[var(--surface-container)] text-[var(--on-surface-variant)]'
                          )}
                        >
                          <span>{selectedMusic === m.id ? '▶  ' : '    '}{m.label} · {m.sub}</span>
                          {selectedMusic === m.id && <span className="material-symbols-outlined" style={{ fontSize: '16px' }}>check</span>}
                        </button>
                      ))}
                    </div>
                  </div>
                )}
                {activeTab === 'filter' && (
                  <div>
                    <p className="text-[12px] font-semibold text-[var(--on-surface-variant)] uppercase tracking-wider mb-3">色调风格</p>
                    <div className="flex gap-3 flex-wrap">
                      {FILTER_OPTIONS.map((f) => (
                        <button key={f.id} onClick={() => setSelectedFilter(f.id)} className="flex flex-col items-center gap-1.5">
                          <div
                            className={cn('w-14 h-14 rounded-xl bg-gradient-to-br', f.from, f.to)}
                            style={{ outline: selectedFilter === f.id ? '2.5px solid var(--primary-container)' : 'none', outlineOffset: '2px' }}
                          />
                          <span className={cn('text-[11px] font-medium', selectedFilter === f.id ? 'text-[var(--primary-container)]' : 'text-[var(--on-surface-variant)]')}>
                            {f.name}
                          </span>
                        </button>
                      ))}
                    </div>
                  </div>
                )}
                {activeTab === 'text' && (
                  <div>
                    <p className="text-[12px] font-semibold text-[var(--on-surface-variant)] uppercase tracking-wider mb-3">AI 文案</p>
                    <div className="bg-[var(--surface-container-lowest)] rounded-xl p-3.5">
                      <p className="text-[13px] text-[var(--on-surface)] leading-relaxed">
                        "家或许让你感觉日常太平淡，但请，偶尔抬起头看看那片海蓝色的天空"
                      </p>
                    </div>
                    <div className="flex gap-2 mt-2.5">
                      <button className="text-[12px] text-[var(--primary-container)] font-semibold px-3 py-1.5 bg-[var(--primary-container)]/10 rounded-full">重新生成</button>
                      <button className="text-[12px] text-[var(--on-surface-variant)] font-medium px-3 py-1.5 bg-[var(--surface-container)] rounded-full">使用这个</button>
                    </div>
                  </div>
                )}
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* Action bar — always visible at bottom */}
        <div className="px-5 pb-10 pt-2 flex gap-3 flex-none border-t border-[var(--outline-variant)]/15">
          <motion.button
            onClick={() => { store.reset(); router.push('/'); }}
            className="flex-none w-12 h-12 rounded-2xl bg-[var(--surface-container-low)] flex items-center justify-center"
            whileTap={{ scale: 0.88 }}
            title="重新创作"
          >
            <span className="material-symbols-outlined text-[var(--on-surface-variant)]" style={{ fontSize: '19px' }}>replay</span>
          </motion.button>
          <motion.button
            onClick={handleSave}
            className="flex-1 h-12 rounded-2xl bg-gradient-to-r from-[#a33e09] to-[#e8713c] text-white text-[15px] font-bold flex items-center justify-center gap-2 shadow-md shadow-orange-200/50"
            whileTap={{ scale: 0.96 }}
          >
            {saved ? <span className="material-symbols-outlined text-white" style={{ fontSize: '20px' }}>check</span> : <span className="material-symbols-outlined text-white" style={{ fontSize: '20px' }}>download</span>}
            {saved ? '已保存 ✓' : '保存视频'}
          </motion.button>
          <motion.button
            onClick={handleShare}
            className="flex-none w-12 h-12 rounded-2xl bg-[var(--surface-container-low)] flex items-center justify-center"
            whileTap={{ scale: 0.88 }}
            title="分享"
          >
            {shared
              ? <span className="material-symbols-outlined text-[var(--primary-container)]" style={{ fontSize: '19px' }}>check</span>
              : <span className="material-symbols-outlined text-[var(--on-surface-variant)]" style={{ fontSize: '19px' }}>share</span>}
          </motion.button>
        </div>
      </motion.div>
    </div>
  );
}
