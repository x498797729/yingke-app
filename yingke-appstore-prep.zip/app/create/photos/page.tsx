'use client';

import { useState, useRef, useCallback, Suspense } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import { motion, AnimatePresence } from 'framer-motion';
import { store, PhotoFile, SceneType } from '@/lib/store';
import { createPreviewUrl, generateId, cn } from '@/lib/utils';

const MIN_PHOTOS = 3;
const MAX_PHOTOS = 20;

// ─── Photo Preview Modal ──────────────────────────────────────────────────────
function PhotoPreviewModal({ url, onClose }: { url: string; onClose: () => void }) {
  return (
    <AnimatePresence>
      <motion.div
        className="fixed inset-0 z-[100] flex items-center justify-center"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        onClick={onClose}
      >
        <div className="absolute inset-0 bg-black/90 backdrop-blur-sm" />
        <motion.img
          src={url}
          alt=""
          className="relative z-10 max-w-[90vw] max-h-[80vh] rounded-2xl object-contain shadow-2xl"
          initial={{ scale: 0.85, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          exit={{ scale: 0.85, opacity: 0 }}
          transition={{ type: 'spring', stiffness: 350, damping: 30 }}
          onClick={(e) => e.stopPropagation()}
        />
        <button
          className="absolute top-10 right-5 w-9 h-9 rounded-full bg-white/15 backdrop-blur-sm flex items-center justify-center"
          onClick={onClose}
        >
          <span className="material-symbols-outlined" style={{ fontSize: '18px', color: 'white', fontVariationSettings: "'FILL' 0" }}>close</span>
        </button>
      </motion.div>
    </AnimatePresence>
  );
}

// ─── Grid Cell ────────────────────────────────────────────────────────────────
function GridCell({
  photo,
  index,
  isDragging,
  isOver,
  onRemove,
  onPreview,
  onPointerDown,
  onPointerUp,
  onPointerEnter,
}: {
  photo: PhotoFile;
  index: number;
  isDragging: boolean;
  isOver: boolean;
  onRemove: (id: string) => void;
  onPreview: (url: string) => void;
  onPointerDown: (id: string) => void;
  onPointerUp: () => void;
  onPointerEnter: (idx: number) => void;
}) {
  return (
    <motion.div
      className={cn(
        'relative aspect-square rounded-[0.875rem] overflow-hidden touch-manipulation select-none',
        isDragging ? 'opacity-40 scale-95 ring-2 ring-[var(--primary-container)]' : '',
        isOver && !isDragging ? 'ring-2 ring-[var(--primary-container)] scale-105' : '',
      )}
      layout
      initial={{ opacity: 0, scale: 0.85 }}
      animate={{ opacity: 1, scale: isDragging ? 0.95 : 1 }}
      exit={{ opacity: 0, scale: 0.85 }}
      transition={{ duration: 0.18 }}
      onPointerDown={() => onPointerDown(photo.id)}
      onPointerUp={onPointerUp}
      onPointerEnter={() => onPointerEnter(index)}
      onPointerCancel={onPointerUp}
    >
      <img
        src={photo.previewUrl}
        alt=""
        className="w-full h-full object-cover pointer-events-none"
        draggable={false}
      />
      <div className="absolute inset-0 bg-black/10" />

      {/* Order badge */}
      <div className="absolute top-1.5 right-1.5 w-6 h-6 rounded-full bg-[var(--primary-container)] flex items-center justify-center shadow-sm">
        <span className="text-[11px] font-bold text-white">{index + 1}</span>
      </div>

      {/* Remove button */}
      <button
        className="absolute top-1.5 left-1.5 w-5 h-5 rounded-full bg-black/50 flex items-center justify-center"
        onPointerDown={(e) => e.stopPropagation()}
        onClick={(e) => { e.stopPropagation(); onRemove(photo.id); }}
      >
        <span className="material-symbols-outlined" style={{ fontSize: '12px', color: 'white', fontVariationSettings: "'FILL' 0" }}>close</span>
      </button>

      {/* Preview button */}
      <button
        className="absolute bottom-1.5 right-1.5 w-5 h-5 rounded-full bg-black/40 flex items-center justify-center"
        onPointerDown={(e) => e.stopPropagation()}
        onClick={(e) => { e.stopPropagation(); onPreview(photo.previewUrl); }}
      >
        <span className="material-symbols-outlined" style={{ fontSize: '11px', color: 'white', fontVariationSettings: "'FILL' 0" }}>visibility</span>
      </button>
    </motion.div>
  );
}

// ─── Main ─────────────────────────────────────────────────────────────────────
function PhotoPickerContent() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const presetScene = searchParams.get('scene') as SceneType | null;

  const [photos, setPhotos] = useState<PhotoFile[]>([]);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [draggingId, setDraggingId] = useState<string | null>(null);
  const [overIdx, setOverIdx] = useState<number | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const longPressTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const isDraggingRef = useRef(false);

  const handleFileChange = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    if (!files.length) return;
    const remaining = MAX_PHOTOS - photos.length;
    const newPhotos: PhotoFile[] = files.slice(0, remaining).map((file, i) => ({
      id: generateId(),
      file,
      previewUrl: createPreviewUrl(file),
      order: photos.length + i,
    }));
    setPhotos((prev) => [...prev, ...newPhotos]);
    e.target.value = '';
  }, [photos.length]);

  const removePhoto = (id: string) => {
    setPhotos((prev) => prev.filter((p) => p.id !== id).map((p, i) => ({ ...p, order: i })));
  };

  const handleNext = () => {
    if (photos.length < MIN_PHOTOS) return;
    store.setPhotos(photos);
    if (presetScene) store.setScene(presetScene);
    router.push('/create/scene');
  };

  // ─── Drag handlers ──────────────────────────────────────────────────────────
  const onPointerDown = useCallback((id: string) => {
    isDraggingRef.current = false;
    longPressTimer.current = setTimeout(() => {
      isDraggingRef.current = true;
      setDraggingId(id);
      navigator.vibrate?.(40);
    }, 380);
  }, []);

  const onPointerUp = useCallback(() => {
    if (longPressTimer.current) clearTimeout(longPressTimer.current);

    if (isDraggingRef.current && draggingId !== null && overIdx !== null) {
      setPhotos((prev) => {
        const fromIdx = prev.findIndex((p) => p.id === draggingId);
        if (fromIdx === -1 || fromIdx === overIdx) return prev;
        const next = [...prev];
        const [moved] = next.splice(fromIdx, 1);
        next.splice(overIdx, 0, moved);
        return next.map((p, i) => ({ ...p, order: i }));
      });
      navigator.vibrate?.(20);
    }

    isDraggingRef.current = false;
    setDraggingId(null);
    setOverIdx(null);
  }, [draggingId, overIdx]);

  const onPointerEnter = useCallback((idx: number) => {
    if (isDraggingRef.current) setOverIdx(idx);
  }, []);

  const canGoNext = photos.length >= MIN_PHOTOS;
  const isInDragMode = draggingId !== null;

  return (
    <div className="flex flex-col h-screen bg-[var(--surface)]" onPointerUp={onPointerUp}>
      {/* Nav */}
      <motion.div
        className="glass flex items-center justify-between px-5 py-4 sticky top-0 z-50"
        initial={{ opacity: 0, y: -16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4, ease: [0.22, 1, 0.36, 1] }}
      >
        <motion.button
          onClick={() => router.back()}
          className="w-9 h-9 flex items-center justify-center rounded-full bg-[var(--surface-container-low)]"
          whileTap={{ scale: 0.9 }}
        >
          <span className="material-symbols-outlined" style={{ fontSize: '20px', color: 'var(--on-surface)', fontVariationSettings: "'FILL' 0" }}>arrow_back_ios</span>
        </motion.button>
        <span className="text-[15px] font-semibold text-[var(--on-surface)]">选择照片</span>
        <motion.button
          onClick={handleNext}
          disabled={!canGoNext}
          whileTap={canGoNext ? { scale: 0.9 } : {}}
          className={cn(
            'text-[14px] font-semibold px-3 py-1.5 rounded-full',
            canGoNext ? 'text-[var(--primary-container)]' : 'text-[var(--outline)] cursor-not-allowed'
          )}
        >
          下一步
        </motion.button>
      </motion.div>

      {/* Count header */}
      <div className="px-5 py-3 flex items-center justify-between">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-[22px] font-bold text-[var(--on-surface)]">
              已选择 {photos.length}/{MAX_PHOTOS}
            </span>
            <AnimatePresence>
              {canGoNext && (
                <motion.div initial={{ scale: 0, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0 }}>
                  <span className="material-symbols-outlined" style={{ fontSize: '20px', color: 'var(--primary-container)', fontVariationSettings: "'FILL' 1" }}>check_circle</span>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
          <AnimatePresence mode="wait">
            {photos.length === 0 ? null : !canGoNext ? (
              <motion.p
                key="hint-more"
                className="text-[12px] text-[var(--on-surface-variant)] mt-0.5"
                initial={{ opacity: 0, y: 4 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}
              >
                再选 {MIN_PHOTOS - photos.length} 张即可继续
              </motion.p>
            ) : isInDragMode ? (
              <motion.p
                key="hint-drag"
                className="text-[12px] text-[var(--primary-container)] mt-0.5 font-medium"
                initial={{ opacity: 0, y: 4 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}
              >
                拖到目标位置后松手
              </motion.p>
            ) : (
              <motion.p
                key="hint-ok"
                className="text-[12px] text-[var(--on-surface-variant)] mt-0.5"
                initial={{ opacity: 0, y: 4 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}
              >
                长按照片可拖拽调整顺序
              </motion.p>
            )}
          </AnimatePresence>
        </div>
        <button
          onClick={() => fileInputRef.current?.click()}
          className="flex items-center gap-1 text-[13px] font-medium text-[var(--on-surface-variant)] bg-[var(--surface-container-low)] px-3 py-1.5 rounded-full"
        >
          相册 <span className="material-symbols-outlined" style={{ fontSize: '14px', fontVariationSettings: "'FILL' 0" }}>expand_more</span>
        </button>
      </div>

      {/* Grid */}
      <div
        className="flex-1 overflow-y-auto"
        style={{ touchAction: isInDragMode ? 'none' : 'auto' }}
      >
        {photos.length === 0 ? (
          <motion.button
            onClick={() => fileInputRef.current?.click()}
            className="mx-5 w-[calc(100%-40px)] aspect-square rounded-[1.5rem] bg-[var(--surface-container-low)] flex flex-col items-center justify-center gap-4"
            whileTap={{ scale: 0.97 }}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
          >
            <div className="w-16 h-16 rounded-2xl bg-[var(--surface-container)] flex items-center justify-center">
              <span className="material-symbols-outlined" style={{ fontSize: '28px', color: 'var(--outline)', fontVariationSettings: "'FILL' 0" }}>image</span>
            </div>
            <div className="text-center">
              <p className="text-[15px] font-semibold text-[var(--on-surface)]">点击选择照片</p>
              <p className="text-[13px] text-[var(--on-surface-variant)] mt-1">
                支持照片和视频 · 最多 {MAX_PHOTOS} 张
              </p>
            </div>
          </motion.button>
        ) : (
          <div className="px-3 pb-4">
            <div className="grid grid-cols-3 gap-1.5">
              <AnimatePresence>
                {photos.map((photo, idx) => (
                  <GridCell
                    key={photo.id}
                    photo={photo}
                    index={idx}
                    isDragging={draggingId === photo.id}
                    isOver={overIdx === idx && draggingId !== photo.id}
                    onRemove={removePhoto}
                    onPreview={setPreviewUrl}
                    onPointerDown={onPointerDown}
                    onPointerUp={onPointerUp}
                    onPointerEnter={onPointerEnter}
                  />
                ))}
              </AnimatePresence>

              {/* Add more — always at end, naturally positioned by grid */}
              {photos.length < MAX_PHOTOS && (
                <motion.button
                  onClick={() => fileInputRef.current?.click()}
                  className="aspect-square rounded-[0.875rem] bg-[var(--surface-container-low)] flex flex-col items-center justify-center gap-1"
                  whileTap={{ scale: 0.93 }}
                  layout
                >
                  <div className="w-8 h-8 rounded-full bg-[var(--surface-container)] flex items-center justify-center">
                    <span className="material-symbols-outlined" style={{ fontSize: '18px', color: 'var(--outline)', fontVariationSettings: "'FILL' 0" }}>add</span>
                  </div>
                  <span className="text-[10px] text-[var(--on-surface-variant)]">添加</span>
                </motion.button>
              )}
            </div>
          </div>
        )}
      </div>

      {/* Bottom selected bar */}
      <AnimatePresence>
        {photos.length > 0 && (
          <motion.div
            className="glass border-t border-[var(--outline-variant)]/15 px-4 pt-3 pb-8"
            initial={{ y: 80, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            exit={{ y: 80, opacity: 0 }}
            transition={{ type: 'spring', stiffness: 350, damping: 30 }}
          >
            <div className="flex items-center justify-between mb-2.5">
              <span className="text-[11px] text-[var(--on-surface-variant)] font-medium">
                {canGoNext ? '顺序预览' : `还需选 ${MIN_PHOTOS - photos.length} 张`}
              </span>
              <button onClick={() => setPhotos([])} className="text-[12px] text-[var(--primary-container)] font-semibold">
                清空
              </button>
            </div>
            <div className="flex gap-2 overflow-x-auto pb-1">
              {photos.map((p, i) => (
                <div key={p.id} className="flex-none relative">
                  <img src={p.previewUrl} alt="" className="w-14 h-14 rounded-xl object-cover" />
                  <div className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-[var(--primary-container)] flex items-center justify-center">
                    <span className="text-[9px] font-bold text-white">{i + 1}</span>
                  </div>
                </div>
              ))}
              {photos.length < MAX_PHOTOS && (
                <button
                  onClick={() => fileInputRef.current?.click()}
                  className="flex-none w-14 h-14 rounded-xl bg-[var(--surface-container-low)] flex items-center justify-center border-2 border-dashed border-[var(--outline-variant)]"
                >
                  <span className="material-symbols-outlined" style={{ fontSize: '18px', color: 'var(--outline)', fontVariationSettings: "'FILL' 0" }}>add</span>
                </button>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {photos.length === 0 && (
        <div className="px-5 pb-10 pt-3">
          <motion.button
            onClick={() => fileInputRef.current?.click()}
            className="w-full py-4 rounded-[1.5rem] bg-gradient-to-r from-[#a33e09] to-[#e8713c] text-white text-[15px] font-bold shadow-lg shadow-orange-200/40"
            whileTap={{ scale: 0.97 }}
          >
            从相册选择照片
          </motion.button>
        </div>
      )}

      <input
        ref={fileInputRef}
        type="file"
        multiple
        accept="image/*,video/*"
        className="hidden"
        onChange={handleFileChange}
      />

      {/* Photo preview modal */}
      {previewUrl && <PhotoPreviewModal url={previewUrl} onClose={() => setPreviewUrl(null)} />}
    </div>
  );
}

export default function PhotoPickerPage() {
  return (
    <Suspense>
      <PhotoPickerContent />
    </Suspense>
  );
}
