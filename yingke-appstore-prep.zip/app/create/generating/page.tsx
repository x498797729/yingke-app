'use client';

import { useEffect, useRef, useState } from 'react';
import { useRouter } from 'next/navigation';
import { motion, AnimatePresence } from 'framer-motion';
import { store, SCENES } from '@/lib/store';
import { cn } from '@/lib/utils';
import { composeVideoCanvas } from '@/lib/video-composer';

const TIPS = [
  '映刻 AI 会根据音节自动排列画面，为你锁定高光时刻',
  '正在分析照片构图，寻找最佳剪辑节奏...',
  '为你挑选最适配的转场效果，让每一帧都恰到好处',
  'AI 正在用小红书审美为你精心排序每一张画面',
  '快好了，马上就能看到你的精彩成片！',
];

function buildProjectTitle(sceneName: string) {
  const dateLabel = new Intl.DateTimeFormat('zh-CN', {
    month: 'numeric',
    day: 'numeric',
  }).format(new Date());

  return `${sceneName} · ${dateLabel}`;
}

async function updateProjectRecord(
  projectId: string,
  payload: {
    status?: string;
    generatedVideoUrl?: string | null;
  }
) {
  const response = await fetch('/api/projects', {
    method: 'PUT',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      id: projectId,
      ...payload,
    }),
  });

  if (!response.ok) {
    throw new Error('更新项目状态失败');
  }
}

async function uploadGeneratedVideo(videoUrl: string) {
  const response = await fetch(videoUrl);
  const blob = await response.blob();
  const formData = new FormData();
  formData.append('file', new File([blob], `yingke-${Date.now()}.webm`, { type: blob.type || 'video/webm' }));

  const uploadResponse = await fetch('/api/uploads', {
    method: 'POST',
    body: formData,
  });

  if (!uploadResponse.ok) {
    throw new Error('上传视频失败');
  }

  const data = (await uploadResponse.json()) as {
    ok: boolean;
    url?: string;
  };

  if (!data.url) {
    throw new Error('未拿到视频地址');
  }

  return data.url;
}

export default function GeneratingPage() {
  const router = useRouter();
  const [progress, setProgress] = useState(0);
  const [stage, setStage] = useState('准备中...');
  const [tipIndex, setTipIndex] = useState(0);
  const [thumbs, setThumbs] = useState<string[]>([]);
  const [error, setError] = useState<string | null>(null);
  const hasStarted = useRef(false);

  useEffect(() => {
    const state = store.get();
    if (!state.scene || state.photos.length === 0) {
      router.replace('/create/photos');
      return;
    }
    setThumbs(state.photos.slice(0, 6).map((p) => p.previewUrl));
  }, [router]);

  useEffect(() => {
    if (thumbs.length === 0 || hasStarted.current) return;
    hasStarted.current = true;

    const runGeneration = async () => {
      const state = store.get();
      const scene = SCENES.find((item) => item.id === state.scene);
      const title = buildProjectTitle(scene?.name ?? '映刻作品');

      let projectId = state.projectId;
      if (!projectId) {
        const response = await fetch('/api/projects', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            title,
            sceneId: state.scene,
            sceneName: scene?.name ?? '',
            status: 'generating',
          }),
        });

        if (!response.ok) {
          throw new Error('创建项目记录失败');
        }

        const data = (await response.json()) as {
          ok: boolean;
          project?: { id: number };
        };
        projectId = String(data.project?.id ?? '');

        if (!projectId) {
          throw new Error('未拿到项目编号');
        }

        store.setProjectId(projectId);
      }

      try {
        const localVideoUrl = await composeVideoCanvas({
          photos: state.photos,
          scene: state.scene!,
          onProgress: (p, s) => {
            setProgress(p);
            setStage(s);
          },
        });

        setStage('上传视频中...');
        const uploadedVideoUrl = await uploadGeneratedVideo(localVideoUrl);
        store.setGeneratedVideoUrl(uploadedVideoUrl);
        await updateProjectRecord(projectId, {
          status: 'completed',
          generatedVideoUrl: uploadedVideoUrl,
        }).catch(() => {});
        router.push('/create/preview');
      } catch (err) {
        console.error(err);
        if (projectId) {
          await updateProjectRecord(projectId, {
            status: 'failed',
          }).catch(() => {});
        }
        setError('视频合成遇到问题，请重试');
      }
    };

    runGeneration().catch((err) => {
      console.error(err);
      setError('项目初始化失败，请重试');
    });
  }, [thumbs, router]);

  useEffect(() => {
    const t = setInterval(() => setTipIndex((i) => (i + 1) % TIPS.length), 3500);
    return () => clearInterval(t);
  }, []);

  const circumference = 2 * Math.PI * 52;
  const dashOffset = circumference * (1 - progress);

  const handleRetry = () => {
    setError(null);
    setProgress(0);
    hasStarted.current = false;
    const state = store.get();
    setThumbs(state.photos.slice(0, 6).map((p) => p.previewUrl));
  };

  return (
    <div className="flex flex-col h-screen bg-[var(--surface)]">
      {/* Top bar */}
      <div className="flex items-center justify-between px-5 pt-12 pb-4">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-full bg-gradient-to-br from-[#E8713C] to-[#a33e09] flex items-center justify-center shadow-sm shadow-orange-200/50">
            <span className="text-white text-[13px] font-bold">映</span>
          </div>
          <span className="text-[16px] font-bold text-[var(--on-surface)]">映刻 YingKe</span>
        </div>
      </div>

      {/* Main */}
      <div className="flex-1 flex flex-col items-center justify-center px-8">
        {/* Progress ring */}
        <motion.div
          className="relative mb-10"
          initial={{ scale: 0.8, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ duration: 0.5, ease: [0.25, 0.1, 0.25, 1] }}
        >
          {/* Ambient glow */}
          <div
            className="absolute inset-0 rounded-full -z-10"
            style={{
              background: `radial-gradient(circle, rgba(232,113,60,${0.08 + progress * 0.12}) 0%, transparent 70%)`,
              transform: 'scale(1.4)',
            }}
          />

          <svg width="148" height="148" viewBox="0 0 148 148" className="-rotate-90">
            <circle cx="74" cy="74" r="52" fill="none" stroke="var(--surface-container)" strokeWidth="7" />
            <motion.circle
              cx="74"
              cy="74"
              r="52"
              fill="none"
              stroke="url(#pg)"
              strokeWidth="7"
              strokeLinecap="round"
              strokeDasharray={circumference}
              strokeDashoffset={dashOffset}
              style={{ transition: 'stroke-dashoffset 0.4s ease' }}
            />
            <defs>
              <linearGradient id="pg" x1="0%" y1="0%" x2="100%" y2="0%">
                <stop offset="0%" stopColor="#a33e09" />
                <stop offset="100%" stopColor="#e8713c" />
              </linearGradient>
            </defs>
          </svg>

          {/* Center */}
          <div className="absolute inset-0 flex items-center justify-center">
            {error ? (
              <span className="text-3xl">😔</span>
            ) : (
              <span className="material-symbols-outlined text-[var(--primary)]" style={{ fontSize: '52px', fontVariationSettings: "'FILL' 1" }}>auto_fix_high</span>
            )}
          </div>
        </motion.div>

        {/* Text */}
        <motion.div
          className="text-center mb-2"
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
        >
          <h2 className="text-[20px] font-bold text-[var(--on-surface)] mb-1.5">
            {error ? '遇到问题了' : 'AI 正在为你编排...'}
          </h2>
          <p className="text-[14px] text-[var(--on-surface-variant)]">{error ?? stage}</p>
          {!error && (
            <p className="text-[12px] text-[var(--outline)] mt-1">
              {Math.round(progress * 100)}% · 预计 15-30 秒
            </p>
          )}
        </motion.div>

        {error && (
          <motion.button
            onClick={handleRetry}
            className="mt-5 px-8 py-3 rounded-full bg-gradient-to-r from-[#a33e09] to-[#e8713c] text-white text-[15px] font-bold"
            whileTap={{ scale: 0.95 }}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
          >
            重新生成
          </motion.button>
        )}

        {/* Photo thumbnails — max 5 shown, fixed size to avoid overflow */}
        {!error && thumbs.length > 0 && (
          <motion.div
            className="mt-12 flex justify-center gap-2 px-6 overflow-hidden"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
          >
            {thumbs.slice(0, 5).map((url, i) => {
              const activeIdx = thumbs.length > 0
                ? Math.min(Math.floor(progress * thumbs.slice(0, 5).length), thumbs.slice(0, 5).length - 1)
                : 0;
              const isActive = i === activeIdx;
              const isDone = i < activeIdx;
              return (
                <motion.div
                  key={i}
                  animate={{ opacity: isDone ? 0.5 : isActive ? 1 : 0.35 }}
                  transition={{ duration: 0.25 }}
                  className="relative flex-none w-11 h-11"
                >
                  <img
                    src={url}
                    alt=""
                    className="w-full h-full object-cover rounded-xl"
                    style={{
                      outline: isActive ? '2px solid var(--primary-container)' : 'none',
                      outlineOffset: '2px',
                    }}
                  />
                  {isDone && (
                    <div className="absolute inset-0 rounded-xl bg-[var(--primary-container)]/20 flex items-center justify-center">
                      <span className="text-[10px] text-[var(--primary-container)] font-bold">✓</span>
                    </div>
                  )}
                </motion.div>
              );
            })}
          </motion.div>
        )}
      </div>

      {/* Tip */}
      {!error && (
        <div className="px-8 pb-10 text-center">
          <p className="text-[10px] font-semibold text-[var(--outline)] tracking-[0.15em] uppercase mb-2">
            SMART EDITING TIP
          </p>
          <AnimatePresence mode="wait">
            <motion.p
              key={tipIndex}
              className="text-[13px] text-[var(--on-surface-variant)] leading-relaxed"
              initial={{ opacity: 0, y: 6 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -6 }}
              transition={{ duration: 0.3 }}
            >
              {TIPS[tipIndex]}
            </motion.p>
          </AnimatePresence>
        </div>
      )}

      {/* Bottom tab bar (decorative) */}
      <div className="glass border-t border-[var(--outline-variant)]/15 px-8 pb-safe-8 pt-4 flex-none">
        <div className="flex items-center justify-around opacity-50 pointer-events-none">
          {[
            { icon: 'movie_filter', active: false },
            { icon: 'music_note', active: false },
            { icon: 'auto_fix_high', active: true },
            { icon: 'text_fields', active: false },
          ].map(({ icon, active }, i) => (
            <div
              key={i}
              className={cn(
                'w-10 h-10 rounded-full flex items-center justify-center',
                active ? 'bg-gradient-to-tr from-[#a33e09] to-[#e8713c]' : ''
              )}
            >
              <span
                className="material-symbols-outlined"
                style={{
                  fontSize: '20px',
                  color: active ? 'white' : 'var(--on-surface-variant)',
                  fontVariationSettings: active ? "'FILL' 1" : "'FILL' 0",
                }}
              >
                {icon}
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
