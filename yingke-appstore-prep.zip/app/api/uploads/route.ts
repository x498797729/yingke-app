import { mkdir, writeFile } from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';

function sanitizeFilename(name: string) {
  return name.replace(/[^a-zA-Z0-9._-]/g, '-');
}

export async function POST(request: Request) {
  try {
    const formData = await request.formData();
    const file = formData.get('file');

    if (!(file instanceof File)) {
      return Response.json(
        { ok: false, error: 'file is required' },
        { status: 400 }
      );
    }

    const isVideo = file.type.startsWith('video/');
    const isImage = file.type.startsWith('image/');

    if (!isVideo && !isImage) {
      return Response.json(
        { ok: false, error: 'unsupported file type' },
        { status: 400 }
      );
    }

    const folderName = isVideo ? 'videos' : 'images';
    const uploadDir = path.join(process.cwd(), 'public', 'uploads', folderName);
    await mkdir(uploadDir, { recursive: true });

    const ext = path.extname(file.name) || (isVideo ? '.webm' : '.jpg');
    const filename = `${Date.now()}-${crypto.randomUUID()}-${sanitizeFilename(
      path.basename(file.name, ext)
    )}${ext}`;
    const buffer = Buffer.from(await file.arrayBuffer());
    const filePath = path.join(uploadDir, filename);

    await writeFile(filePath, buffer);

    return Response.json({
      ok: true,
      url: `/uploads/${folderName}/${filename}`,
      filename,
      mimeType: file.type,
      size: file.size,
    });
  } catch (error) {
    const message =
      error instanceof Error ? error.message : 'Unknown upload error';

    return Response.json({ ok: false, error: message }, { status: 500 });
  }
}
