import { updateProject } from '@/lib/projects';

type RouteParams = {
  params: Promise<{
    id: string;
  }>;
};

function badRequest(message: string) {
  return Response.json({ ok: false, error: message }, { status: 400 });
}

export async function PATCH(request: Request, { params }: RouteParams) {
  try {
    const { id } = await params;
    const projectId = Number(id);

    if (Number.isNaN(projectId) || projectId <= 0) {
      return badRequest('invalid project id');
    }

    const body = (await request.json()) as {
      title?: string;
      sceneId?: string;
      sceneName?: string;
      status?: string;
      thumbnailUrl?: string | null;
      generatedVideoUrl?: string | null;
      durationSeconds?: number | null;
    };

    const project = await updateProject(projectId, {
      title: body.title?.trim(),
      sceneId: body.sceneId?.trim(),
      sceneName: body.sceneName?.trim(),
      status: body.status?.trim(),
      thumbnailUrl: body.thumbnailUrl,
      generatedVideoUrl: body.generatedVideoUrl,
      durationSeconds:
        typeof body.durationSeconds === 'number' ? body.durationSeconds : undefined,
    });

    return Response.json({
      ok: true,
      project,
    });
  } catch (error) {
    const message =
      error instanceof Error ? error.message : 'Unknown project update error';

    return Response.json({ ok: false, error: message }, { status: 500 });
  }
}
