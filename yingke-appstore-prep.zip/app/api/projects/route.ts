import {
  createProject,
  deleteProject,
  listProjects,
  updateProject,
} from '@/lib/projects';

function badRequest(message: string) {
  return Response.json({ ok: false, error: message }, { status: 400 });
}

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const limitParam = searchParams.get('limit');
    const limit = limitParam ? Number(limitParam) : 20;
    const projects = await listProjects(Number.isNaN(limit) ? 20 : limit);

    return Response.json({
      ok: true,
      projects,
    });
  } catch (error) {
    const message =
      error instanceof Error ? error.message : 'Unknown projects error';

    return Response.json({ ok: false, error: message }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const body = (await request.json()) as {
      title?: string;
      sceneId?: string;
      sceneName?: string;
      status?: string;
      thumbnailUrl?: string | null;
      generatedVideoUrl?: string | null;
      durationSeconds?: number | null;
    };

    if (!body.title?.trim()) {
      return badRequest('title is required');
    }

    if (!body.sceneId?.trim()) {
      return badRequest('sceneId is required');
    }

    if (!body.sceneName?.trim()) {
      return badRequest('sceneName is required');
    }

    const project = await createProject({
      title: body.title.trim(),
      sceneId: body.sceneId.trim(),
      sceneName: body.sceneName.trim(),
      status: body.status?.trim() || 'draft',
      thumbnailUrl: body.thumbnailUrl ?? null,
      generatedVideoUrl: body.generatedVideoUrl ?? null,
      durationSeconds:
        typeof body.durationSeconds === 'number' ? body.durationSeconds : null,
    });

    return Response.json(
      {
        ok: true,
        project,
      },
      { status: 201 }
    );
  } catch (error) {
    const message =
      error instanceof Error ? error.message : 'Unknown projects error';

    return Response.json({ ok: false, error: message }, { status: 500 });
  }
}

export async function PUT(request: Request) {
  try {
    const body = (await request.json()) as {
      id?: number | string;
      title?: string;
      sceneId?: string;
      sceneName?: string;
      status?: string;
      thumbnailUrl?: string | null;
      generatedVideoUrl?: string | null;
      durationSeconds?: number | null;
    };

    const projectId = Number(body.id);
    if (Number.isNaN(projectId) || projectId <= 0) {
      return badRequest('id is required');
    }

    const project = await updateProject(projectId, {
      title: body.title?.trim(),
      sceneId: body.sceneId?.trim(),
      sceneName: body.sceneName?.trim(),
      status: body.status?.trim(),
      thumbnailUrl: body.thumbnailUrl,
      generatedVideoUrl: body.generatedVideoUrl,
      durationSeconds:
        typeof body.durationSeconds === 'number' ? body.durationSeconds : undefined,
    });

    return Response.json({
      ok: true,
      project,
    });
  } catch (error) {
    const message =
      error instanceof Error ? error.message : 'Unknown projects error';

    return Response.json({ ok: false, error: message }, { status: 500 });
  }
}

export async function DELETE(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const id = searchParams.get('id');
    const projectId = Number(id);

    if (Number.isNaN(projectId) || projectId <= 0) {
      return badRequest('id is required');
    }

    const deleted = await deleteProject(projectId);

    return Response.json({
      ok: true,
      deleted,
    });
  } catch (error) {
    const message =
      error instanceof Error ? error.message : 'Unknown projects error';

    return Response.json({ ok: false, error: message }, { status: 500 });
  }
}
