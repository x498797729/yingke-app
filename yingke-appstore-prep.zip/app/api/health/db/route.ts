import { pingDatabase } from '@/lib/db';

export async function GET() {
  try {
    const result = await pingDatabase();

    return Response.json({
      ok: true,
      database: result.database_name,
      serverTime: result.now,
    });
  } catch (error) {
    const message =
      error instanceof Error ? error.message : 'Unknown database error';

    return Response.json(
      {
        ok: false,
        error: message,
      },
      { status: 500 }
    );
  }
}
