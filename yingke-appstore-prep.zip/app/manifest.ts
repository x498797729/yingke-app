import type { MetadataRoute } from "next";

export default function manifest(): MetadataRoute.Manifest {
  return {
    name: "映刻 YingKe",
    short_name: "映刻",
    description: "选几张照片，AI 帮你生成更有氛围感的生活 Vlog。",
    start_url: "/",
    scope: "/",
    display: "standalone",
    orientation: "portrait",
    background_color: "#f9f9f6",
    theme_color: "#f9f9f6",
    lang: "zh-CN",
    categories: ["photo", "video", "lifestyle"],
    icons: [
      {
        src: "/icon",
        sizes: "512x512",
        type: "image/png",
      },
      {
        src: "/apple-icon",
        sizes: "180x180",
        type: "image/png",
      },
    ],
  };
}
