import type { Metadata } from "next";
import Link from "next/link";
import { appMeta } from "@/lib/app-meta";

export const metadata: Metadata = {
  title: "支持与帮助",
  description: "映刻 YingKe 支持与帮助",
};

const items = [
  "如果生成失败，请优先重试一次，并确认素材数量与格式正常。",
  "如果作品列表没有刷新，请返回首页或重新进入“我的”页面。",
  "如果你准备提交 App Store，请把本页中的联系信息替换为真实邮箱、官网或工单入口。",
];

export default function SupportPage() {
  return (
    <main className="min-h-dvh bg-[var(--surface)] px-6 py-8 text-[var(--on-surface)]">
      <div className="mx-auto flex max-w-3xl flex-col gap-6">
        <Link
          href="/"
          className="w-fit rounded-full bg-white px-4 py-2 text-sm font-medium text-[var(--on-surface-variant)] shadow-sm"
        >
          返回映刻
        </Link>

        <header className="rounded-[28px] bg-white p-6 shadow-sm">
          <p className="text-sm font-medium text-[var(--primary)]">映刻 YingKe</p>
          <h1 className="mt-3 text-3xl font-semibold tracking-tight">支持与帮助</h1>
          <p className="mt-3 text-sm leading-7 text-[var(--on-surface-variant)]">
            这是给 TestFlight 和后续 App Store 审核准备的支持页面基础版。
            你至少还需要补一个真实可达的联系邮箱或官网地址。
          </p>
          <div className="mt-4 rounded-2xl bg-[var(--surface-container-low)] px-4 py-3 text-sm text-[var(--on-surface-variant)]">
            支持邮箱：{appMeta.supportEmail}
            <br />
            支持页面：{appMeta.supportWebsite}
          </div>
        </header>

        <section className="rounded-[28px] bg-white p-6 shadow-sm">
          <h2 className="text-lg font-semibold">当前可直接使用的说明</h2>
          <ul className="mt-4 grid gap-3 text-sm leading-7 text-[var(--on-surface-variant)]">
            {items.map((item) => (
              <li key={item} className="rounded-2xl bg-[var(--surface-container-low)] px-4 py-3">
                {item}
              </li>
            ))}
          </ul>
        </section>
      </div>
    </main>
  );
}
