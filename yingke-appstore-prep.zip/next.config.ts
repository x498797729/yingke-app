import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  allowedDevOrigins: ['150.158.18.248'],
  turbopack: {
    root: __dirname,
  },
  images: {
    remotePatterns: [
      { protocol: 'https', hostname: 'images.unsplash.com' },
    ],
  },
};

export default nextConfig;
