'use client';

import { useRouter } from 'next/navigation';
import { cn } from '@/lib/utils';

interface NavBarProps {
  title?: string;
  rightLabel?: string;
  rightAction?: () => void;
  rightDisabled?: boolean;
  showBack?: boolean;
  transparent?: boolean;
  className?: string;
}

export function NavBar({
  title,
  rightLabel,
  rightAction,
  rightDisabled,
  showBack = true,
  transparent = false,
  className,
}: NavBarProps) {
  const router = useRouter();

  return (
    <div
      className={cn(
        'flex items-center justify-between px-5 py-4 sticky top-0 z-50',
        transparent ? 'bg-transparent' : 'glass',
        className
      )}
    >
      {showBack ? (
        <button
          onClick={() => router.back()}
          className="w-9 h-9 flex items-center justify-center rounded-full bg-[var(--surface-container-low)] active:scale-95 transition-transform"
        >
          <span className="material-symbols-outlined" style={{ fontSize: '20px', color: 'var(--on-surface)', fontVariationSettings: "'FILL' 0" }}>arrow_back_ios</span>
        </button>
      ) : (
        <div className="w-9" />
      )}

      {title && (
        <span className="text-[15px] font-semibold text-[var(--on-surface)]">{title}</span>
      )}

      {rightLabel ? (
        <button
          onClick={rightAction}
          disabled={rightDisabled}
          className={cn(
            'text-[14px] font-semibold px-3 py-1 rounded-full transition-all',
            rightDisabled
              ? 'text-[var(--outline)] cursor-not-allowed'
              : 'text-[var(--primary-container)] active:opacity-70'
          )}
        >
          {rightLabel}
        </button>
      ) : (
        <div className="w-16" />
      )}
    </div>
  );
}
