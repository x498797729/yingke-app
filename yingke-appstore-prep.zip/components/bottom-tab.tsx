'use client';

import { usePathname, useRouter } from 'next/navigation';
import { motion, AnimatePresence } from 'framer-motion';
import { cn } from '@/lib/utils';

const tabs = [
  { icon: 'movie_filter', label: '首页', href: '/' },
  { icon: 'music_note', label: '探索', href: '/explore' },
  { icon: 'auto_fix_high', label: '创作', href: '/create/photos' },
  { icon: 'text_fields', label: '我的', href: '/profile' },
];

export function BottomTab() {
  const pathname = usePathname();
  const router = useRouter();

  return (
    <div className="anim-slide-up bg-[var(--surface)]/85 backdrop-blur-2xl rounded-t-[2.5rem] px-8 pt-3 pb-safe-8 shadow-[0_-8px_32px_rgba(138,114,104,0.08)] border-t border-[var(--outline-variant)]/10 flex-none" style={{ animationDelay: '0.08s' }}>
      <div className="flex items-center justify-around">
        {tabs.map((tab) => {
          const isActive = tab.href === '/' ? pathname === '/' : pathname.startsWith(tab.href);
          return (
            <motion.button
              key={tab.href}
              onClick={() => router.push(tab.href)}
              className="flex flex-col items-center gap-1 py-1 relative"
              whileTap={{ scale: 0.82 }}
              transition={{ type: 'spring', stiffness: 500, damping: 22 }}
            >
              {/* Active glow behind icon */}
              <AnimatePresence>
                {isActive && (
                  <motion.div
                    layoutId="tab-glow"
                    className="absolute inset-0 rounded-full bg-[#e8713c]/15"
                    initial={{ opacity: 0, scale: 0.6 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0, scale: 0.6 }}
                    transition={{ type: 'spring', stiffness: 400, damping: 28 }}
                  />
                )}
              </AnimatePresence>

              <motion.div
                className={cn(
                  'w-12 h-12 rounded-full flex items-center justify-center relative z-10',
                  isActive
                    ? 'bg-gradient-to-tr from-[#a33e09] to-[#e8713c] shadow-lg shadow-[#e8713c]/25'
                    : ''
                )}
                animate={isActive ? { scale: [0.88, 1.08, 1] } : { scale: 1 }}
                transition={{ duration: 0.38, ease: [0.22, 1, 0.36, 1] }}
              >
                <motion.span
                  className="material-symbols-outlined"
                  style={{
                    fontSize: '22px',
                    color: isActive ? 'white' : '#8a7268',
                    fontVariationSettings: isActive ? "'FILL' 1" : "'FILL' 0",
                  }}
                  animate={isActive ? { rotate: [0, -10, 6, 0] } : { rotate: 0 }}
                  transition={{ duration: 0.45, ease: 'easeOut' }}
                >
                  {tab.icon}
                </motion.span>
              </motion.div>

              {/* Active label dot */}
              <AnimatePresence>
                {isActive && (
                  <motion.div
                    className="w-1 h-1 rounded-full bg-[#e8713c]"
                    initial={{ opacity: 0, scale: 0 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0, scale: 0 }}
                    transition={{ type: 'spring', stiffness: 500, damping: 25, delay: 0.1 }}
                  />
                )}
                {!isActive && <div className="w-1 h-1" />}
              </AnimatePresence>
            </motion.button>
          );
        })}
      </div>
    </div>
  );
}
