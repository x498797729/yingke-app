'use client';

import { useState } from 'react';
import { cn } from '@/lib/utils';

interface ImageWithSkeletonProps {
  src: string;
  alt: string;
  className?: string;
  skeletonClassName?: string;
}

export function ImageWithSkeleton({ src, alt, className, skeletonClassName }: ImageWithSkeletonProps) {
  const [loaded, setLoaded] = useState(false);
  const [error, setError] = useState(false);

  return (
    <div className="relative w-full h-full">
      {/* Shimmer skeleton */}
      {!loaded && !error && (
        <div className={cn('absolute inset-0 bg-[var(--surface-container)] overflow-hidden', skeletonClassName)}>
          <div
            className="absolute inset-0"
            style={{
              background: 'linear-gradient(90deg, transparent 0%, rgba(255,255,255,0.4) 50%, transparent 100%)',
              animation: 'shimmer 1.5s infinite',
              backgroundSize: '200% 100%',
            }}
          />
        </div>
      )}
      {error && (
        <div className={cn('absolute inset-0 bg-[var(--surface-container)] flex items-center justify-center', skeletonClassName)}>
          <span className="text-[var(--outline)] text-2xl">🖼️</span>
        </div>
      )}
      <img
        src={src}
        alt={alt}
        className={cn(className, 'transition-opacity duration-300', loaded ? 'opacity-100' : 'opacity-0')}
        onLoad={() => setLoaded(true)}
        onError={() => setError(true)}
      />
    </div>
  );
}
